export type Severity = 'info' | 'warning' | 'error';

export type AmbiguitySource = 'parser' | 'validation';

export interface Ambiguity {
  field: string;
  message: string;
  severity: Severity;
  source: AmbiguitySource;
}

export interface Party {
  name: string | null;
  ico: string | null;
  dic: string | null;
  address: string | null;
}

export interface InvoiceItem {
  description: string;
  quantity: number | null;
  unitPrice: number | null;
  vatRate: number | null;
  vatBase: number | null;
  vatAmount: number | null;
  total: number | null;
}

export interface VatSummaryRow {
  vatRate: number;
  vatBase: number;
  vatAmount: number;
}

export interface InvoiceData {
  invoiceNumber: string | null;
  variableSymbol: string | null;
  constantSymbol: string | null;
  supplier: Party;
  customer: Party;
  issueDate: string | null;
  taxDate: string | null;
  dueDate: string | null;
  items: InvoiceItem[];
  vatSummary: VatSummaryRow[];
  totalAmount: number | null;
  currency: string | null;
  ambiguities: Ambiguity[];
}

export type InvoiceStatus = 'draft' | 'verified';

export interface StoredInvoice {
  id: string;
  fileName: string;
  status: InvoiceStatus;
  rawText: string;
  data: InvoiceData;
  createdAt: string;
  updatedAt: string;
}

export interface AuditEntry {
  id: string;
  invoiceId: string;
  action: string;
  details: Record<string, unknown>;
  createdAt: string;
}
