export function formatAmount(value: number | null, currency?: string | null): string {
  if (value === null) return '—';
  const formatted = new Intl.NumberFormat('cs-CZ', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
  return currency ? `${formatted} ${currency}` : formatted;
}

export function formatDate(iso: string | null): string {
  if (!iso) return '—';
  const [year, month, day] = iso.split('-').map(Number);
  return new Date(year, month - 1, day).toLocaleDateString('cs-CZ');
}

export function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString('cs-CZ', { dateStyle: 'medium', timeStyle: 'short' });
}
