const FIELD_LABELS: Record<string, string> = {
  invoiceNumber: 'Číslo faktury',
  variableSymbol: 'Variabilní symbol',
  constantSymbol: 'Konstantní symbol',
  supplier: 'Dodavatel',
  'supplier.ico': 'IČO dodavatele',
  'supplier.dic': 'DIČ dodavatele',
  customer: 'Odběratel',
  issueDate: 'Datum vystavení',
  taxDate: 'Datum zdanitelného plnění',
  dueDate: 'Datum splatnosti',
  totalAmount: 'Celková částka',
  currency: 'Měna',
  vatSummary: 'Rekapitulace DPH',
  items: 'Položky',
};

export function fieldLabel(field: string): string {
  const itemMatch = /^items\[(\d+)\]\.\w+$/.exec(field);
  if (itemMatch) return `Položka ${Number(itemMatch[1]) + 1}`;
  return FIELD_LABELS[field] ?? field;
}
