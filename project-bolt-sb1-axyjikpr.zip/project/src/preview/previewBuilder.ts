import type { StoredInvoice } from '@/types/invoice';

export type SheetName = 'Invoices' | 'Items' | 'Ambiguities';

export type CellValue = string | number | null;

export interface SheetPreview {
  name: SheetName;
  headers: string[];
  rows: CellValue[][];
}

export interface ExportPreview {
  sheets: SheetPreview[];
}

export const INVOICE_HEADERS = [
  'invoiceNumber',
  'variableSymbol',
  'constantSymbol',
  'supplierName',
  'supplierICO',
  'supplierDIC',
  'customerName',
  'customerICO',
  'customerDIC',
  'issueDate',
  'taxDate',
  'dueDate',
  'totalAmount',
  'currency',
];

export const ITEM_HEADERS = [
  'invoiceNumber',
  'itemIndex',
  'description',
  'quantity',
  'unitPrice',
  'vatRate',
  'vatBase',
  'vatAmount',
  'total',
];

export const AMBIGUITY_HEADERS = ['invoiceNumber', 'field', 'message', 'severity'];

export function buildExportPreview(invoices: StoredInvoice[]): ExportPreview {
  const invoiceRows: CellValue[][] = [];
  const itemRows: CellValue[][] = [];
  const ambiguityRows: CellValue[][] = [];

  for (const { data } of invoices) {
    const number = data.invoiceNumber;
    invoiceRows.push([
      number,
      data.variableSymbol,
      data.constantSymbol,
      data.supplier.name,
      data.supplier.ico,
      data.supplier.dic,
      data.customer.name,
      data.customer.ico,
      data.customer.dic,
      data.issueDate,
      data.taxDate,
      data.dueDate,
      data.totalAmount,
      data.currency,
    ]);

    data.items.forEach((item, index) => {
      itemRows.push([
        number,
        index + 1,
        item.description,
        item.quantity,
        item.unitPrice,
        item.vatRate,
        item.vatBase,
        item.vatAmount,
        item.total,
      ]);
    });

    for (const ambiguity of data.ambiguities) {
      ambiguityRows.push([number, ambiguity.field, ambiguity.message, ambiguity.severity]);
    }
  }

  return {
    sheets: [
      { name: 'Invoices', headers: INVOICE_HEADERS, rows: invoiceRows },
      { name: 'Items', headers: ITEM_HEADERS, rows: itemRows },
      { name: 'Ambiguities', headers: AMBIGUITY_HEADERS, rows: ambiguityRows },
    ],
  };
}
