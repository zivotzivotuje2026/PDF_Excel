import { FileIngestionService } from '@/pipeline/ingestion/fileIngestion';
import { OcrService } from '@/pipeline/ocr/ocrService';
import { TesseractOcrProvider } from '@/pipeline/ocr/tesseractOcrProvider';
import { InvoiceParser } from '@/pipeline/parsing/invoiceParser';
import { CzechInvoiceStrategy } from '@/pipeline/parsing/strategies/czechInvoiceStrategy';
import { InvoicePipeline } from '@/pipeline/invoicePipeline';
import { SupabaseStorageProvider } from '@/persistence/supabaseStorageProvider';
import { ExcelExporter } from '@/export/excelExporter';
import { JsonExporter } from '@/export/jsonExporter';
import { CsvExporter } from '@/export/csvExporter';
import type { IExporter } from '@/export/exportTypes';

export const storage = new SupabaseStorageProvider();

export const invoicePipeline = new InvoicePipeline(
  new FileIngestionService(),
  new OcrService(new TesseractOcrProvider()),
  new InvoiceParser([new CzechInvoiceStrategy()]),
);

export interface ExportFormat {
  id: 'xlsx' | 'json' | 'csv-invoices' | 'csv-items';
  label: string;
  fileSuffix: string;
  exporter: IExporter;
}

export const EXPORT_FORMATS: ExportFormat[] = [
  { id: 'xlsx', label: 'Excel (XLSX)', fileSuffix: '', exporter: new ExcelExporter() },
  { id: 'json', label: 'JSON', fileSuffix: '', exporter: new JsonExporter() },
  { id: 'csv-invoices', label: 'CSV faktury', fileSuffix: '-faktury', exporter: new CsvExporter('Invoices') },
  { id: 'csv-items', label: 'CSV položky', fileSuffix: '-polozky', exporter: new CsvExporter('Items') },
];
