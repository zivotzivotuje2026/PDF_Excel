import { supabase } from '@/lib/supabase';
import type { AuditEntry, InvoiceData, InvoiceStatus, StoredInvoice } from '@/types/invoice';
import type { IStorageProvider, NewInvoice } from '@/persistence/storageProvider';

interface InvoiceRow {
  id: string;
  file_name: string;
  status: InvoiceStatus;
  raw_text: string;
  data: InvoiceData;
  created_at: string;
  updated_at: string;
}

interface AuditRow {
  id: string;
  invoice_id: string;
  action: string;
  details: Record<string, unknown>;
  created_at: string;
}

const INVOICE_COLUMNS = 'id, file_name, status, raw_text, data, created_at, updated_at';

function toStoredInvoice(row: InvoiceRow): StoredInvoice {
  return {
    id: row.id,
    fileName: row.file_name,
    status: row.status,
    rawText: row.raw_text,
    data: row.data,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

function denormalize(data: InvoiceData) {
  return {
    invoice_number: data.invoiceNumber,
    supplier_name: data.supplier.name,
    customer_name: data.customer.name,
    total_amount: data.totalAmount,
    currency: data.currency,
  };
}

function failOnError(error: { message: string } | null): void {
  if (error) throw new Error(error.message);
}

export class SupabaseStorageProvider implements IStorageProvider {
  async listInvoices(): Promise<StoredInvoice[]> {
    const { data, error } = await supabase
      .from('invoices')
      .select(INVOICE_COLUMNS)
      .order('created_at', { ascending: false });
    failOnError(error);
    return ((data ?? []) as InvoiceRow[]).map(toStoredInvoice);
  }

  async createInvoice({ fileName, rawText, data }: NewInvoice): Promise<StoredInvoice> {
    const { data: row, error } = await supabase
      .from('invoices')
      .insert({ file_name: fileName, raw_text: rawText, data, status: 'draft', ...denormalize(data) })
      .select(INVOICE_COLUMNS)
      .single();
    failOnError(error);
    return toStoredInvoice(row as InvoiceRow);
  }

  async updateInvoice(id: string, data: InvoiceData, status: InvoiceStatus): Promise<StoredInvoice> {
    const { data: row, error } = await supabase
      .from('invoices')
      .update({ data, status, updated_at: new Date().toISOString(), ...denormalize(data) })
      .eq('id', id)
      .select(INVOICE_COLUMNS)
      .single();
    failOnError(error);
    return toStoredInvoice(row as InvoiceRow);
  }

  async deleteInvoice(id: string): Promise<void> {
    const { error } = await supabase.from('invoices').delete().eq('id', id);
    failOnError(error);
  }

  async appendAudit(invoiceId: string, action: string, details: Record<string, unknown>): Promise<void> {
    const { error } = await supabase.from('audit_log').insert({ invoice_id: invoiceId, action, details });
    failOnError(error);
  }

  async listAudit(invoiceId: string): Promise<AuditEntry[]> {
    const { data, error } = await supabase
      .from('audit_log')
      .select('id, invoice_id, action, details, created_at')
      .eq('invoice_id', invoiceId)
      .order('created_at', { ascending: false });
    failOnError(error);
    return ((data ?? []) as AuditRow[]).map((row) => ({
      id: row.id,
      invoiceId: row.invoice_id,
      action: row.action,
      details: row.details,
      createdAt: row.created_at,
    }));
  }
}
