import type { AuditEntry, StoredInvoice, InvoiceData } from '@/types/invoice';

export interface NewInvoice {
  fileName: string;
  rawText: string;
  data: InvoiceData;
}

export interface IStorageProvider {
  listInvoices(): Promise<StoredInvoice[]>;
  createInvoice(input: NewInvoice): Promise<StoredInvoice>;
  updateInvoice(id: string, data: InvoiceData, status: StoredInvoice['status']): Promise<StoredInvoice>;
  deleteInvoice(id: string): Promise<void>;
  appendAudit(invoiceId: string, action: string, details: Record<string, unknown>): Promise<void>;
  listAudit(invoiceId: string): Promise<AuditEntry[]>;
}
