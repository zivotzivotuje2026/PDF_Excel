import { useState } from 'react';
import { FileSearch } from 'lucide-react';
import { useInvoiceLibrary } from '@/hooks/useInvoiceLibrary';
import { AppHeader } from '@/components/layout/AppHeader';
import { UploadPanel } from '@/components/upload/UploadPanel';
import { InvoiceList } from '@/components/invoices/InvoiceList';
import { InvoiceReview } from '@/components/review/InvoiceReview';

export default function App() {
  const library = useInvoiceLibrary();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = library.invoices.find((invoice) => invoice.id === selectedId) ?? null;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <AppHeader invoices={library.invoices} />
      <main className="mx-auto grid max-w-7xl gap-6 px-4 py-8 lg:grid-cols-[360px_minmax(0,1fr)]">
        <aside className="space-y-6">
          <UploadPanel
            onCreated={(invoice) => {
              library.upsert(invoice);
              setSelectedId(invoice.id);
            }}
          />
          <InvoiceList
            invoices={library.invoices}
            status={library.status}
            error={library.error}
            selectedId={selectedId}
            onSelect={setSelectedId}
            onRetry={() => void library.refresh()}
          />
        </aside>

        <section className="min-w-0">
          {selected ? (
            <InvoiceReview
              key={selected.id}
              invoice={selected}
              onUpdated={library.upsert}
              onDeleted={(id) => {
                library.remove(id);
                setSelectedId(null);
              }}
            />
          ) : (
            <EmptyReview />
          )}
        </section>
      </main>
    </div>
  );
}

function EmptyReview() {
  return (
    <div className="flex min-h-[24rem] flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white/60 p-10 text-center">
      <span className="flex h-14 w-14 items-center justify-center rounded-full bg-teal-50 text-teal-700">
        <FileSearch className="h-6 w-6" />
      </span>
      <h2 className="mt-5 text-lg font-semibold text-slate-900">Vyberte fakturu ke kontrole</h2>
      <p className="mt-2 max-w-sm text-sm text-slate-500">
        Po nahrání se zde zobrazí vytěžené údaje, položky a nejednoznačnosti. Před exportem je můžete zkontrolovat a opravit.
      </p>
    </div>
  );
}
