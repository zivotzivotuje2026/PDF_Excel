import { AlertTriangle, FileText, Loader2, RefreshCw } from 'lucide-react';
import type { StoredInvoice } from '@/types/invoice';
import type { LibraryStatus } from '@/hooks/useInvoiceLibrary';
import { formatAmount, formatDate } from '@/lib/format';
import { StatusBadge } from '@/components/ui/Badges';
import { Button } from '@/components/ui/Button';

interface InvoiceListProps {
  invoices: StoredInvoice[];
  status: LibraryStatus;
  error: string | null;
  selectedId: string | null;
  onSelect: (id: string) => void;
  onRetry: () => void;
}

export function InvoiceList({ invoices, status, error, selectedId, onSelect, onRetry }: InvoiceListProps) {
  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-slate-900">Zpracované faktury</h2>
        {status === 'ready' && (
          <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-600">
            {invoices.length}
          </span>
        )}
      </div>

      {status === 'loading' && (
        <p className="mt-6 flex items-center justify-center gap-2 text-sm text-slate-500">
          <Loader2 className="h-4 w-4 animate-spin" /> Načítám faktury
        </p>
      )}

      {status === 'error' && (
        <div className="mt-4 space-y-3 rounded-lg bg-rose-50 p-4 text-sm text-rose-700">
          <p>Faktury se nepodařilo načíst. {error}</p>
          <Button variant="secondary" icon={<RefreshCw className="h-4 w-4" />} onClick={onRetry}>
            Zkusit znovu
          </Button>
        </div>
      )}

      {status === 'ready' && invoices.length === 0 && (
        <p className="mt-6 text-center text-sm text-slate-500">Zatím tu nejsou žádné faktury.</p>
      )}

      {status === 'ready' && invoices.length > 0 && (
        <ul className="mt-4 max-h-[28rem] space-y-2 overflow-y-auto pr-1">
          {invoices.map((invoice) => (
            <InvoiceListItem
              key={invoice.id}
              invoice={invoice}
              selected={invoice.id === selectedId}
              onSelect={() => onSelect(invoice.id)}
            />
          ))}
        </ul>
      )}
    </section>
  );
}

function InvoiceListItem({ invoice, selected, onSelect }: { invoice: StoredInvoice; selected: boolean; onSelect: () => void }) {
  const { data } = invoice;
  const hasBlockingIssues = data.ambiguities.some((item) => item.severity !== 'info');

  return (
    <li>
      <button
        type="button"
        onClick={onSelect}
        className={`group w-full rounded-xl border p-3 text-left transition-all duration-150 hover:-translate-y-px hover:shadow-md ${
          selected ? 'border-teal-600 bg-teal-50/60 ring-1 ring-teal-600' : 'border-slate-200 bg-white hover:border-slate-300'
        }`}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-start gap-2.5">
            <FileText className="mt-0.5 h-4 w-4 shrink-0 text-slate-400 group-hover:text-teal-700" />
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-slate-900">{data.invoiceNumber ?? 'Bez čísla faktury'}</p>
              <p className="truncate text-xs text-slate-500">{data.supplier.name ?? invoice.fileName}</p>
            </div>
          </div>
          <StatusBadge status={invoice.status} />
        </div>
        <div className="mt-2 flex items-center justify-between text-xs text-slate-600">
          <span>{formatDate(data.issueDate)}</span>
          <span className="flex items-center gap-1.5 font-medium text-slate-800">
            {hasBlockingIssues && <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />}
            {formatAmount(data.totalAmount, data.currency)}
          </span>
        </div>
      </button>
    </li>
  );
}
