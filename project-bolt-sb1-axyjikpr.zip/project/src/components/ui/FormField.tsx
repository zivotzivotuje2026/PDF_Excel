import type { InputHTMLAttributes, ReactNode } from 'react';

interface FormFieldProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
  hint?: ReactNode;
}

const INPUT_CLASS =
  'w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-sm transition-colors placeholder:text-slate-400 hover:border-slate-400 focus:border-teal-600 focus:outline-none focus:ring-2 focus:ring-teal-600/20';

export function FormField({ label, hint, className = '', ...inputProps }: FormFieldProps) {
  return (
    <label className={`block space-y-1.5 ${className}`}>
      <span className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</span>
      <input {...inputProps} className={INPUT_CLASS} />
      {hint && <span className="block text-xs text-slate-500">{hint}</span>}
    </label>
  );
}

export const INPUT_CELL_CLASS =
  'w-full rounded-md border border-transparent bg-transparent px-2 py-1.5 text-sm text-slate-900 transition-colors hover:border-slate-300 focus:border-teal-600 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-600/20';
