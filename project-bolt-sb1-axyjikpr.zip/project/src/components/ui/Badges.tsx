import type { InvoiceStatus, Severity } from '@/types/invoice';

const STATUS_STYLES: Record<InvoiceStatus, { label: string; className: string }> = {
  draft: { label: 'Ke kontrole', className: 'bg-amber-50 text-amber-800 ring-amber-200' },
  verified: { label: 'Ověřeno', className: 'bg-emerald-50 text-emerald-800 ring-emerald-200' },
};

const SEVERITY_STYLES: Record<Severity, { label: string; className: string }> = {
  error: { label: 'Chyba', className: 'bg-rose-50 text-rose-700 ring-rose-200' },
  warning: { label: 'Upozornění', className: 'bg-amber-50 text-amber-800 ring-amber-200' },
  info: { label: 'Info', className: 'bg-sky-50 text-sky-800 ring-sky-200' },
};

const BADGE_BASE = 'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ring-inset';

export function StatusBadge({ status }: { status: InvoiceStatus }) {
  const style = STATUS_STYLES[status];
  return <span className={`${BADGE_BASE} ${style.className}`}>{style.label}</span>;
}

export function SeverityBadge({ severity }: { severity: Severity }) {
  const style = SEVERITY_STYLES[severity];
  return <span className={`${BADGE_BASE} ${style.className}`}>{style.label}</span>;
}
