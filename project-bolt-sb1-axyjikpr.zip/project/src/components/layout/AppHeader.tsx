import { useState } from 'react';
import { Download, ReceiptText } from 'lucide-react';
import type { StoredInvoice } from '@/types/invoice';
import { EXPORT_FORMATS } from '@/app/services';
import { exportInvoices } from '@/export/exportInvoices';
import { errorMessage } from '@/lib/errors';
import { Button } from '@/components/ui/Button';

interface AppHeaderProps {
  invoices: StoredInvoice[];
}

export function AppHeader({ invoices }: AppHeaderProps) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const xlsx = EXPORT_FORMATS[0];

  async function handleExportAll() {
    setBusy(true);
    setError(null);
    try {
      await exportInvoices(xlsx, invoices, 'faktury-vse');
    } catch (cause) {
      setError(errorMessage(cause));
    } finally {
      setBusy(false);
    }
  }

  return (
    <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-700 text-white shadow-sm">
            <ReceiptText className="h-5 w-5" />
          </span>
          <div>
            <p className="text-base font-semibold leading-tight text-slate-900">Faktury chytře</p>
            <p className="text-xs text-slate-500">Vytěžení faktur do přehledné tabulky</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <Button
            variant="primary"
            icon={<Download className="h-4 w-4" />}
            disabled={invoices.length === 0 || busy}
            onClick={() => void handleExportAll()}
          >
            {busy ? 'Připravuji…' : 'Exportovat vše do Excelu'}
          </Button>
          {error && <p className="text-xs text-rose-700">{error}</p>}
        </div>
      </div>
    </header>
  );
}
