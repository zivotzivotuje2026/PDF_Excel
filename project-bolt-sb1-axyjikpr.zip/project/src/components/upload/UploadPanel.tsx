import { useRef, useState, type DragEvent } from 'react';
import { FileUp, Loader2, AlertCircle } from 'lucide-react';
import type { StoredInvoice } from '@/types/invoice';
import type { OcrProgress } from '@/pipeline/ocr/ocrTypes';
import { invoicePipeline, storage } from '@/app/services';
import { errorMessage } from '@/lib/errors';
import { Button } from '@/components/ui/Button';

interface UploadPanelProps {
  onCreated: (invoice: StoredInvoice) => void;
}

const ACCEPT = 'application/pdf,image/png,image/jpeg,image/webp';

export function UploadPanel({ onCreated }: UploadPanelProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [working, setWorking] = useState(false);
  const [progress, setProgress] = useState<OcrProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);

  async function processFile(file: File) {
    setWorking(true);
    setError(null);
    setProgress({ stage: 'Načítám dokument', ratio: 0 });
    try {
      const processed = await invoicePipeline.process(file, setProgress);
      const invoice = await storage.createInvoice({
        fileName: file.name,
        rawText: processed.rawText,
        data: processed.data,
      });
      await storage.appendAudit(invoice.id, 'upload', {
        fileName: file.name,
        textSource: processed.textSource,
        ambiguityCount: processed.data.ambiguities.length,
      });
      onCreated(invoice);
    } catch (cause) {
      console.error('Zpracování faktury selhalo:', cause);
      setError(errorMessage(cause));
    } finally {
      setWorking(false);
      setProgress(null);
      if (inputRef.current) inputRef.current.value = '';
    }
  }

  function handleDrop(event: DragEvent<HTMLLabelElement>) {
    event.preventDefault();
    setDragging(false);
    const file = event.dataTransfer.files[0];
    if (file && !working) void processFile(file);
  }

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <h2 className="text-sm font-semibold text-slate-900">Nová faktura</h2>
      <label
        onDragOver={(event) => {
          event.preventDefault();
          if (!working) setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        className={`mt-4 flex cursor-pointer flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed px-6 py-8 text-center transition-all duration-200 ${
          dragging
            ? 'scale-[1.01] border-teal-600 bg-teal-50'
            : 'border-slate-300 bg-slate-50 hover:border-teal-500 hover:bg-teal-50/50'
        } ${working ? 'pointer-events-none' : ''}`}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT}
          className="sr-only"
          disabled={working}
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void processFile(file);
          }}
        />
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-white text-teal-700 shadow-sm ring-1 ring-slate-200">
          {working ? <Loader2 className="h-5 w-5 animate-spin" /> : <FileUp className="h-5 w-5" />}
        </span>
        {working ? (
          <div className="w-full space-y-2">
            <p className="text-sm font-medium text-slate-800">{progress?.stage ?? 'Zpracovávám fakturu'}</p>
            <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-200">
              <div
                className="h-full rounded-full bg-teal-600 transition-all duration-300"
                style={{ width: `${Math.round((progress?.ratio ?? 0) * 100)}%` }}
              />
            </div>
          </div>
        ) : (
          <>
            <span className="text-sm font-medium text-slate-800">Přetáhněte fakturu sem</span>
            <span className="text-xs text-slate-500">PDF, PNG, JPG nebo WEBP do 20 MB</span>
            <Button variant="secondary" className="pointer-events-none mt-1 py-1.5">
              Vybrat soubor
            </Button>
          </>
        )}
      </label>
      {error && (
        <p className="mt-3 flex items-start gap-2 rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-700">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </p>
      )}
    </section>
  );
}
