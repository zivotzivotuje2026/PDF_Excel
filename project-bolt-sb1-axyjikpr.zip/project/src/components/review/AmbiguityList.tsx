import { AlertTriangle, CheckCircle2, Info, XCircle, type LucideIcon } from 'lucide-react';
import type { Ambiguity, Severity } from '@/types/invoice';
import { SeverityBadge } from '@/components/ui/Badges';
import { Button } from '@/components/ui/Button';
import { fieldLabel } from '@/lib/fieldLabels';

interface AmbiguityListProps {
  ambiguities: Ambiguity[];
  onDismiss: (index: number) => void;
}

const SEVERITY_ORDER: Severity[] = ['error', 'warning', 'info'];

const SEVERITY_ICON: Record<Severity, LucideIcon> = {
  error: XCircle,
  warning: AlertTriangle,
  info: Info,
};

const SEVERITY_ICON_CLASS: Record<Severity, string> = {
  error: 'text-rose-600',
  warning: 'text-amber-600',
  info: 'text-sky-600',
};

export function AmbiguityList({ ambiguities, onDismiss }: AmbiguityListProps) {
  if (ambiguities.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50/60 px-6 py-10 text-center">
        <CheckCircle2 className="h-8 w-8 text-emerald-600" />
        <p className="text-sm font-medium text-emerald-900">Nebyly nalezeny žádné nejednoznačnosti.</p>
      </div>
    );
  }

  const indexed = ambiguities.map((ambiguity, index) => ({ ambiguity, index }));

  return (
    <ul className="space-y-6">
      {SEVERITY_ORDER.map((severity) => {
        const group = indexed.filter(({ ambiguity }) => ambiguity.severity === severity);
        if (group.length === 0) return null;
        return (
          <li key={severity}>
            <ul className="space-y-3">
              {group.map(({ ambiguity, index }) => {
                const Icon = SEVERITY_ICON[ambiguity.severity];
                return (
                  <li
                    key={index}
                    className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:flex-row sm:items-start sm:justify-between"
                  >
                    <div className="flex items-start gap-3">
                      <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${SEVERITY_ICON_CLASS[ambiguity.severity]}`} />
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <SeverityBadge severity={ambiguity.severity} />
                          <span className="text-xs font-medium text-slate-500">{fieldLabel(ambiguity.field)}</span>
                        </div>
                        <p className="text-sm text-slate-800">{ambiguity.message}</p>
                        {ambiguity.source === 'validation' && (
                          <p className="text-xs text-slate-500">Po uložení se kontrola provede znovu.</p>
                        )}
                      </div>
                    </div>
                    <Button variant="ghost" className="shrink-0 py-1.5" onClick={() => onDismiss(index)}>
                      Označit jako vyřešené
                    </Button>
                  </li>
                );
              })}
            </ul>
          </li>
        );
      })}
    </ul>
  );
}
