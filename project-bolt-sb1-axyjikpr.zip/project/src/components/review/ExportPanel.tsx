import { useMemo, useState } from 'react';
import { Download } from 'lucide-react';
import type { StoredInvoice } from '@/types/invoice';
import { buildExportPreview, type SheetName } from '@/preview/previewBuilder';
import { EXPORT_FORMATS, type ExportFormat } from '@/app/services';
import { exportInvoices } from '@/export/exportInvoices';
import { errorMessage } from '@/lib/errors';
import { Button } from '@/components/ui/Button';

interface ExportPanelProps {
  invoice: StoredInvoice;
  dirty: boolean;
}

const SHEET_LABELS: Record<SheetName, string> = {
  Invoices: 'Faktury',
  Items: 'Položky',
  Ambiguities: 'Nejednoznačnosti',
};

export function ExportPanel({ invoice, dirty }: ExportPanelProps) {
  const preview = useMemo(() => buildExportPreview([invoice]), [invoice]);
  const [sheetName, setSheetName] = useState<SheetName>('Invoices');
  const [busyFormat, setBusyFormat] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const activeSheet = preview.sheets.find((sheet) => sheet.name === sheetName) ?? preview.sheets[0];
  const baseName = `faktura-${invoice.data.invoiceNumber ?? invoice.id.slice(0, 8)}`;

  async function handleExport(format: ExportFormat) {
    setBusyFormat(format.id);
    setError(null);
    try {
      await exportInvoices(format, [invoice], baseName);
    } catch (cause) {
      setError(errorMessage(cause));
    } finally {
      setBusyFormat(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="Listy náhledu">
          {preview.sheets.map((sheet) => (
            <button
              key={sheet.name}
              type="button"
              role="tab"
              aria-selected={sheet.name === activeSheet.name}
              onClick={() => setSheetName(sheet.name)}
              className={`rounded-full px-3.5 py-1.5 text-xs font-medium transition-colors ${
                sheet.name === activeSheet.name
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {SHEET_LABELS[sheet.name]} ({sheet.rows.length})
            </button>
          ))}
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-200">
          {activeSheet.rows.length === 0 ? (
            <p className="px-4 py-8 text-center text-sm text-slate-500">Tento list zatím neobsahuje žádné řádky.</p>
          ) : (
            <table className="min-w-full divide-y divide-slate-200 text-xs">
              <thead className="bg-slate-50 text-left font-medium text-slate-600">
                <tr>
                  {activeSheet.headers.map((header) => (
                    <th key={header} className="whitespace-nowrap px-3 py-2">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 bg-white text-slate-800">
                {activeSheet.rows.map((row, rowIndex) => (
                  <tr key={rowIndex} className="hover:bg-slate-50">
                    {row.map((cell, cellIndex) => (
                      <td key={cellIndex} className="whitespace-nowrap px-3 py-2 tabular-nums">
                        {cell === null ? '' : String(cell)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50/70 p-4">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">Stáhnout export</h3>
          <p className="text-xs text-slate-500">
            {dirty
              ? 'Máte neuložené změny. Nejdříve je uložte, aby export obsahoval aktuální údaje.'
              : 'Excel je hlavní formát. JSON a CSV slouží pro další zpracování.'}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {EXPORT_FORMATS.map((format, index) => (
            <Button
              key={format.id}
              variant={index === 0 ? 'primary' : 'secondary'}
              disabled={dirty || busyFormat !== null}
              onClick={() => void handleExport(format)}
              icon={<Download className="h-4 w-4" />}
            >
              {busyFormat === format.id ? 'Připravuji…' : format.label}
            </Button>
          ))}
        </div>
        {error && <p className="text-sm text-rose-700">{error}</p>}
      </div>
    </div>
  );
}
