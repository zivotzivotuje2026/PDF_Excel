import type { ReactNode } from 'react';
import type { InvoiceData, Party } from '@/types/invoice';
import { FormField } from '@/components/ui/FormField';

interface InvoiceFieldsFormProps {
  draft: InvoiceData;
  onChange: (patch: Partial<InvoiceData>) => void;
}

export function InvoiceFieldsForm({ draft, onChange }: InvoiceFieldsFormProps) {
  return (
    <div className="space-y-8">
      <FieldGroup title="Základní údaje">
        <FormField
          label="Číslo faktury"
          value={draft.invoiceNumber ?? ''}
          onChange={(event) => onChange({ invoiceNumber: emptyToNull(event.target.value) })}
        />
        <FormField
          label="Variabilní symbol"
          value={draft.variableSymbol ?? ''}
          onChange={(event) => onChange({ variableSymbol: emptyToNull(event.target.value) })}
        />
        <FormField
          label="Konstantní symbol"
          value={draft.constantSymbol ?? ''}
          onChange={(event) => onChange({ constantSymbol: emptyToNull(event.target.value) })}
        />
        <FormField
          label="Měna"
          value={draft.currency ?? ''}
          onChange={(event) => onChange({ currency: emptyToNull(event.target.value.toUpperCase()) })}
        />
      </FieldGroup>

      <FieldGroup title="Termíny">
        <FormField
          label="Datum vystavení"
          type="date"
          value={draft.issueDate ?? ''}
          onChange={(event) => onChange({ issueDate: emptyToNull(event.target.value) })}
        />
        <FormField
          label="Datum zdanitelného plnění"
          type="date"
          value={draft.taxDate ?? ''}
          onChange={(event) => onChange({ taxDate: emptyToNull(event.target.value) })}
        />
        <FormField
          label="Datum splatnosti"
          type="date"
          value={draft.dueDate ?? ''}
          onChange={(event) => onChange({ dueDate: emptyToNull(event.target.value) })}
        />
      </FieldGroup>

      <PartyFields
        title="Dodavatel"
        party={draft.supplier}
        onChange={(supplier) => onChange({ supplier })}
      />
      <PartyFields
        title="Odběratel"
        party={draft.customer}
        onChange={(customer) => onChange({ customer })}
      />
    </div>
  );
}

function PartyFields({ title, party, onChange }: { title: string; party: Party; onChange: (party: Party) => void }) {
  const update = (patch: Partial<Party>) => onChange({ ...party, ...patch });
  return (
    <FieldGroup title={title}>
      <FormField
        label="Název"
        className="sm:col-span-2"
        value={party.name ?? ''}
        onChange={(event) => update({ name: emptyToNull(event.target.value) })}
      />
      <FormField
        label="IČO"
        value={party.ico ?? ''}
        onChange={(event) => update({ ico: emptyToNull(event.target.value.replace(/\s/g, '')) })}
      />
      <FormField
        label="DIČ"
        value={party.dic ?? ''}
        onChange={(event) => update({ dic: emptyToNull(event.target.value.replace(/\s/g, '')) })}
      />
      <FormField
        label="Adresa"
        className="sm:col-span-2"
        value={party.address ?? ''}
        onChange={(event) => update({ address: emptyToNull(event.target.value) })}
      />
    </FieldGroup>
  );
}

function FieldGroup({ title, children }: { title: string; children: ReactNode }) {
  return (
    <fieldset className="space-y-4">
      <legend className="mb-4 text-sm font-semibold text-slate-900">{title}</legend>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </fieldset>
  );
}

function emptyToNull(value: string): string | null {
  const trimmed = value.trim();
  return trimmed === '' ? null : value;
}
