import { useEffect, useState } from 'react';
import { History, Loader2 } from 'lucide-react';
import type { AuditEntry } from '@/types/invoice';
import { storage } from '@/app/services';
import { formatDateTime } from '@/lib/format';
import { errorMessage } from '@/lib/errors';
import { fieldLabel } from '@/lib/fieldLabels';

interface HistoryPanelProps {
  invoiceId: string;
}

const ACTION_LABELS: Record<string, string> = {
  upload: 'Nahrání a automatické vytěžení',
  manual_edit: 'Ruční úprava údajů',
  verify: 'Ověření faktury',
  export: 'Export',
};

export function HistoryPanel({ invoiceId }: HistoryPanelProps) {
  const [entries, setEntries] = useState<AuditEntry[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    storage
      .listAudit(invoiceId)
      .then((result) => {
        if (active) setEntries(result);
      })
      .catch((cause: unknown) => {
        if (active) setError(errorMessage(cause));
      });
    return () => {
      active = false;
    };
  }, [invoiceId]);

  if (error) return <p className="rounded-lg bg-rose-50 px-4 py-3 text-sm text-rose-700">Historii se nepodařilo načíst. {error}</p>;
  if (!entries) {
    return (
      <p className="flex items-center gap-2 text-sm text-slate-500">
        <Loader2 className="h-4 w-4 animate-spin" /> Načítám historii
      </p>
    );
  }
  if (entries.length === 0) {
    return <p className="py-8 text-center text-sm text-slate-500">Zatím nejsou žádné záznamy.</p>;
  }

  return (
    <ol className="relative space-y-5 border-l border-slate-200 pl-6">
      {entries.map((entry) => (
        <li key={entry.id} className="relative">
          <span className="absolute -left-[1.85rem] flex h-4 w-4 items-center justify-center rounded-full bg-white ring-2 ring-slate-300">
            <History className="h-2.5 w-2.5 text-slate-500" />
          </span>
          <p className="text-sm font-medium text-slate-900">{ACTION_LABELS[entry.action] ?? entry.action}</p>
          <p className="text-xs text-slate-500">{formatDateTime(entry.createdAt)}</p>
          <AuditDetails details={entry.details} />
        </li>
      ))}
    </ol>
  );
}

function AuditDetails({ details }: { details: Record<string, unknown> }) {
  const changed = Array.isArray(details.changedFields) ? (details.changedFields as string[]) : [];
  if (changed.length === 0) return null;
  return <p className="mt-1 text-xs text-slate-600">Změněno: {changed.map(fieldLabel).join(', ')}</p>;
}
