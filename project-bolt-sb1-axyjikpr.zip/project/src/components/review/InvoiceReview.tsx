import { useState } from 'react';
import { CheckCircle2, Save, Trash2 } from 'lucide-react';
import type { InvoiceData, InvoiceStatus, StoredInvoice } from '@/types/invoice';
import { storage } from '@/app/services';
import { buildAmbiguities } from '@/pipeline/validation/invoiceValidator';
import { errorMessage } from '@/lib/errors';
import { formatDate, formatAmount } from '@/lib/format';
import { StatusBadge } from '@/components/ui/Badges';
import { Button } from '@/components/ui/Button';
import { InvoiceFieldsForm } from '@/components/review/InvoiceFieldsForm';
import { ItemsEditor } from '@/components/review/ItemsEditor';
import { AmbiguityList } from '@/components/review/AmbiguityList';
import { ExportPanel } from '@/components/review/ExportPanel';
import { HistoryPanel } from '@/components/review/HistoryPanel';

type ReviewTab = 'fields' | 'items' | 'ambiguities' | 'preview' | 'history';

interface InvoiceReviewProps {
  invoice: StoredInvoice;
  onUpdated: (invoice: StoredInvoice) => void;
  onDeleted: (id: string) => void;
}

interface Notice {
  tone: 'success' | 'error';
  text: string;
}

const EDITABLE_FIELDS: (keyof InvoiceData)[] = [
  'invoiceNumber',
  'variableSymbol',
  'constantSymbol',
  'supplier',
  'customer',
  'issueDate',
  'taxDate',
  'dueDate',
  'items',
  'vatSummary',
  'totalAmount',
  'currency',
];

export function InvoiceReview({ invoice, onUpdated, onDeleted }: InvoiceReviewProps) {
  const [draft, setDraft] = useState<InvoiceData>(invoice.data);
  const [tab, setTab] = useState<ReviewTab>('fields');
  const [busy, setBusy] = useState<'save' | 'verify' | 'delete' | null>(null);
  const [notice, setNotice] = useState<Notice | null>(null);

  const dirty = JSON.stringify(draft) !== JSON.stringify(invoice.data);
  const errorCount = draft.ambiguities.filter((item) => item.severity === 'error').length;

  const patch = (changes: Partial<InvoiceData>) => setDraft((current) => ({ ...current, ...changes }));

  async function persist(verify: boolean) {
    setBusy(verify ? 'verify' : 'save');
    setNotice(null);
    try {
      const next: InvoiceData = { ...draft, ambiguities: buildAmbiguities(draft, draft.ambiguities) };
      const changed = changedFields(invoice.data, next);
      const nextErrors = next.ambiguities.filter((item) => item.severity === 'error').length;

      if (verify && nextErrors > 0) {
        setDraft(next);
        setNotice({ tone: 'error', text: 'Fakturu nelze ověřit, dokud nejsou opraveny všechny chyby.' });
        return;
      }

      const status: InvoiceStatus = verify ? 'verified' : changed.length > 0 ? 'draft' : invoice.status;
      const updated = await storage.updateInvoice(invoice.id, next, status);
      if (changed.length > 0) {
        await storage.appendAudit(invoice.id, 'manual_edit', { changedFields: changed });
      }
      if (verify) {
        await storage.appendAudit(invoice.id, 'verify', {});
      }
      onUpdated(updated);
      setDraft(updated.data);
      setNotice({ tone: 'success', text: verify ? 'Faktura je ověřená.' : 'Změny byly uloženy.' });
    } catch (cause) {
      setNotice({ tone: 'error', text: errorMessage(cause) });
    } finally {
      setBusy(null);
    }
  }

  async function handleDelete() {
    const confirmed = window.confirm('Opravdu smazat tuto fakturu včetně její historie? Tuto akci nelze vrátit.');
    if (!confirmed) return;
    setBusy('delete');
    try {
      await storage.deleteInvoice(invoice.id);
      onDeleted(invoice.id);
    } catch (cause) {
      setNotice({ tone: 'error', text: errorMessage(cause) });
      setBusy(null);
    }
  }

  const tabs: { id: ReviewTab; label: string }[] = [
    { id: 'fields', label: 'Údaje' },
    { id: 'items', label: `Položky (${draft.items.length})` },
    { id: 'ambiguities', label: `Nejednoznačnosti (${draft.ambiguities.length})` },
    { id: 'preview', label: 'Náhled a export' },
    { id: 'history', label: 'Historie' },
  ];

  return (
    <article className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <header className="flex flex-col gap-4 border-b border-slate-200 p-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="truncate text-xl font-semibold text-slate-900">
              {draft.invoiceNumber ?? 'Faktura bez čísla'}
            </h2>
            <StatusBadge status={invoice.status} />
          </div>
          <p className="truncate text-sm text-slate-500">
            {invoice.fileName} · vystaveno {formatDate(draft.issueDate)} · celkem{' '}
            {formatAmount(draft.totalAmount, draft.currency)}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            variant="secondary"
            icon={<Save className="h-4 w-4" />}
            disabled={!dirty || busy !== null}
            onClick={() => void persist(false)}
          >
            {busy === 'save' ? 'Ukládám…' : 'Uložit změny'}
          </Button>
          <Button
            variant="primary"
            icon={<CheckCircle2 className="h-4 w-4" />}
            disabled={busy !== null || (invoice.status === 'verified' && !dirty)}
            onClick={() => void persist(true)}
          >
            {busy === 'verify' ? 'Ověřuji…' : 'Ověřit fakturu'}
          </Button>
          <Button
            variant="ghost"
            icon={<Trash2 className="h-4 w-4" />}
            disabled={busy !== null}
            onClick={() => void handleDelete()}
            aria-label="Smazat fakturu"
            className="text-rose-600 hover:bg-rose-50 hover:text-rose-700"
          >
            Smazat
          </Button>
        </div>
      </header>

      {notice && (
        <p
          role="status"
          className={`mx-6 mt-5 rounded-lg px-4 py-3 text-sm ${
            notice.tone === 'success' ? 'bg-emerald-50 text-emerald-800' : 'bg-rose-50 text-rose-700'
          }`}
        >
          {notice.text}
        </p>
      )}
      {dirty && !notice && (
        <p className="mx-6 mt-5 rounded-lg bg-amber-50 px-4 py-3 text-sm text-amber-800">
          Máte neuložené změny.{errorCount > 0 ? ` Zbývá ${errorCount} chyb k opravě.` : ''}
        </p>
      )}

      <nav className="mt-5 border-b border-slate-200 px-6" role="tablist" aria-label="Sekce faktury">
        <ul className="-mb-px flex gap-6 overflow-x-auto">
          {tabs.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                role="tab"
                aria-selected={tab === item.id}
                onClick={() => setTab(item.id)}
                className={`whitespace-nowrap border-b-2 pb-3 text-sm font-medium transition-colors ${
                  tab === item.id
                    ? 'border-teal-700 text-teal-800'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                {item.label}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-6" role="tabpanel">
        {tab === 'fields' && (
          <div className="space-y-8">
            <InvoiceFieldsForm draft={draft} onChange={patch} />
            <details className="rounded-xl border border-slate-200 bg-slate-50/70 p-4">
              <summary className="cursor-pointer text-sm font-medium text-slate-700">Původní text z dokumentu</summary>
              <pre className="mt-3 max-h-80 overflow-auto whitespace-pre-wrap text-xs leading-relaxed text-slate-600">
                {invoice.rawText}
              </pre>
            </details>
          </div>
        )}
        {tab === 'items' && (
          <ItemsEditor items={draft.items} currency={draft.currency} onChange={(items) => patch({ items })} />
        )}
        {tab === 'ambiguities' && (
          <AmbiguityList
            ambiguities={draft.ambiguities}
            onDismiss={(index) =>
              setDraft((current) => ({
                ...current,
                ambiguities: current.ambiguities.filter((_, position) => position !== index),
              }))
            }
          />
        )}
        {tab === 'preview' && <ExportPanel invoice={invoice} dirty={dirty} />}
        {tab === 'history' && <HistoryPanel key={invoice.updatedAt} invoiceId={invoice.id} />}
      </div>
    </article>
  );
}

function changedFields(previous: InvoiceData, next: InvoiceData): string[] {
  return EDITABLE_FIELDS.filter((field) => JSON.stringify(previous[field]) !== JSON.stringify(next[field]));
}
