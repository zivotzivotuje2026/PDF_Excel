import { useEffect, useState } from 'react';
import { Plus, Trash2 } from 'lucide-react';
import type { InvoiceItem } from '@/types/invoice';
import { parseCzechNumber } from '@/pipeline/parsing/amountParser';
import { formatAmount } from '@/lib/format';
import { Button } from '@/components/ui/Button';
import { INPUT_CELL_CLASS } from '@/components/ui/FormField';

interface ItemsEditorProps {
  items: InvoiceItem[];
  currency: string | null;
  onChange: (items: InvoiceItem[]) => void;
}

const EMPTY_ITEM: InvoiceItem = {
  description: '',
  quantity: null,
  unitPrice: null,
  vatRate: null,
  vatBase: null,
  vatAmount: null,
  total: null,
};

export function ItemsEditor({ items, currency, onChange }: ItemsEditorProps) {
  const updateItem = (index: number, patch: Partial<InvoiceItem>) =>
    onChange(items.map((item, position) => (position === index ? { ...item, ...patch } : item)));

  const removeItem = (index: number) => onChange(items.filter((_, position) => position !== index));

  const totalSum = items.reduce((sum, item) => sum + (item.total ?? 0), 0);

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto rounded-xl border border-slate-200">
        <table className="min-w-full divide-y divide-slate-200 text-sm">
          <thead className="bg-slate-50 text-left text-xs font-medium uppercase tracking-wide text-slate-500">
            <tr>
              <th className="px-3 py-2.5">Popis</th>
              <th className="px-3 py-2.5 text-right">Množství</th>
              <th className="px-3 py-2.5 text-right">Cena/MJ</th>
              <th className="px-3 py-2.5 text-right">DPH %</th>
              <th className="px-3 py-2.5 text-right">Základ</th>
              <th className="px-3 py-2.5 text-right">DPH</th>
              <th className="px-3 py-2.5 text-right">Celkem</th>
              <th className="w-10 px-3 py-2.5" />
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 bg-white">
            {items.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-8 text-center text-sm text-slate-500">
                  Faktura nemá žádné položky. Můžete je přidat ručně.
                </td>
              </tr>
            )}
            {items.map((item, index) => (
              <tr key={index} className="transition-colors hover:bg-slate-50/70">
                <td className="min-w-[14rem] px-2 py-1.5">
                  <input
                    className={INPUT_CELL_CLASS}
                    value={item.description}
                    aria-label={`Popis položky ${index + 1}`}
                    onChange={(event) => updateItem(index, { description: event.target.value })}
                  />
                </td>
                <NumericCell label="Množství" value={item.quantity} onCommit={(value) => updateItem(index, { quantity: value })} />
                <NumericCell label="Cena za jednotku" value={item.unitPrice} onCommit={(value) => updateItem(index, { unitPrice: value })} />
                <NumericCell label="Sazba DPH" value={item.vatRate} onCommit={(value) => updateItem(index, { vatRate: value })} />
                <NumericCell label="Základ" value={item.vatBase} onCommit={(value) => updateItem(index, { vatBase: value })} />
                <NumericCell label="DPH" value={item.vatAmount} onCommit={(value) => updateItem(index, { vatAmount: value })} />
                <NumericCell label="Celkem" value={item.total} onCommit={(value) => updateItem(index, { total: value })} />
                <td className="px-2 py-1.5 text-right">
                  <button
                    type="button"
                    onClick={() => removeItem(index)}
                    aria-label={`Odebrat položku ${index + 1}`}
                    className="rounded-md p-1.5 text-slate-400 transition-colors hover:bg-rose-50 hover:text-rose-600"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          {items.length > 0 && (
            <tfoot className="bg-slate-50 text-sm font-semibold text-slate-900">
              <tr>
                <td colSpan={6} className="px-3 py-2.5 text-right">
                  Součet položek
                </td>
                <td className="px-3 py-2.5 text-right tabular-nums">{formatAmount(totalSum, currency)}</td>
                <td />
              </tr>
            </tfoot>
          )}
        </table>
      </div>
      <Button
        variant="secondary"
        icon={<Plus className="h-4 w-4" />}
        onClick={() => onChange([...items, { ...EMPTY_ITEM }])}
      >
        Přidat položku
      </Button>
    </div>
  );
}

function NumericCell({ label, value, onCommit }: { label: string; value: number | null; onCommit: (value: number | null) => void }) {
  const [text, setText] = useState(formatEditable(value));

  useEffect(() => {
    setText(formatEditable(value));
  }, [value]);

  const commit = () => {
    if (text.trim() === '') {
      onCommit(null);
      return;
    }
    const parsed = parseCzechNumber(text);
    if (parsed === null) {
      setText(formatEditable(value));
      return;
    }
    onCommit(parsed);
  };

  return (
    <td className="px-2 py-1.5">
      <input
        inputMode="decimal"
        aria-label={label}
        value={text}
        onChange={(event) => setText(event.target.value)}
        onBlur={commit}
        onKeyDown={(event) => {
          if (event.key === 'Enter') event.currentTarget.blur();
        }}
        className={`${INPUT_CELL_CLASS} min-w-[5.5rem] text-right tabular-nums`}
      />
    </td>
  );
}

function formatEditable(value: number | null): string {
  return value === null ? '' : String(value).replace('.', ',');
}
