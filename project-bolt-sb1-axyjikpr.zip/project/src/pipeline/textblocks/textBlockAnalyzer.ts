export type BlockKind = 'party' | 'items' | 'summary' | 'payment' | 'other';

export interface TextBlock {
  kind: BlockKind;
  lines: string[];
}

const PARTY_LABEL = /^(dodavatel|odběratel|odberatel|prodávající|kupující|zákazník|zakaznik|příjemce|objednatel)\b/iu;
const PAYMENT_HINT = /IBAN|SWIFT|bankovní\s+spojení|číslo\s+účtu|\búčet\b/iu;
const SUMMARY_HINT = /k\s+úhradě|celkem|základ\s+dph|rekapitulace|sazba\s+dph/iu;
const ITEMS_HINT = /popis|položk|název\s+zboží|množství|cena\s+za/iu;

export function normalizeText(text: string): string {
  return text.replace(/\b(?:\p{Lu} ){3,}\p{Lu}\b/gu, (run) => run.replace(/ /g, ''));
}

export function normalizeLines(text: string): string[] {
  return text
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => line.replace(/[\t\u00a0\u202f]+/g, ' ').replace(/ {2,}/g, ' ').trim())
    .filter((line, index, all) => line.length > 0 || (index > 0 && all[index - 1].length > 0));
}

export function analyzeTextBlocks(lines: string[]): TextBlock[] {
  const blocks: TextBlock[] = [];
  let current: string[] = [];

  const flush = () => {
    if (current.length === 0) return;
    blocks.push({ kind: classifyBlock(current), lines: current });
    current = [];
  };

  for (const line of lines) {
    if (line === '') {
      flush();
      continue;
    }
    if (PARTY_LABEL.test(line)) flush();
    current.push(line);
  }
  flush();
  return blocks;
}

function classifyBlock(lines: string[]): BlockKind {
  const text = lines.join('\n');
  if (PARTY_LABEL.test(lines[0])) return 'party';
  if (PAYMENT_HINT.test(text)) return 'payment';
  if (ITEMS_HINT.test(text) && lines.length > 2) return 'items';
  if (SUMMARY_HINT.test(text)) return 'summary';
  return 'other';
}
