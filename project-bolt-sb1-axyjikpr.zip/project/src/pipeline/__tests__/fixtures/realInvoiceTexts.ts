export const REAL_INVOICE_ANDAX_2026032 = `-----------------------------
FUBO Private Gym –
Hradec Králové s . r . o .
V Kopečku 169 / 14
500 03 Hradec Králové
IČ 23761059
není plátce DPH
F A K T U R A − D A Ň O V Ý D O K L A D č. 2026 032
ANDAX s. r. o.
IČO 62026216
předmět plnění základ sazba částka částka
DIČ CZ 62026216
DPH DPH DPH celkem
zapsaná v obchodním rejstříku,
vedeném u Městského soudu
v Praze /
zajištění úklidu provozních prostor
oddíl C, vložka 153044
za sjednané období – srpen 2026 2.892,56 21 % 607,44 3.500,00
registrované sídlo /
fakturační adresa :
Přívozní 2 / 1054
170 00 Praha 7
k úhradě 3 . 500 , 00
bankovní účet CZK :
č. 2200810605 / 2010
IBAN formát
CZ 4220 1000 0000 2200 8106 05
SWIFT kód FIO CZPP XXX /
Fio Banka
telefon : +420 777 797 734
Veškeré finanční údaje jsou v Kč .
nebo +420 777 727 754
mail : ANDAX @ centrum. cz
datum zdanitelného plnění: 31. 08. 2026
http: // www. ANDAX. cz
termín splatnosti: 10. 09. 2026
údaje pro platbu: bankovním převodem
VS = 2026032
KS = 308
v zastoupení dodavatele: Jiří Hušek
V Praze dne 02. 09. 2026`;

export const REAL_INVOICE_IDOKLAD_20260038 = `Faktura - daňový doklad 20260038
Dodavatel
ANDAX s.r.o.
Přívozní 1054/2
170 00 Praha
Česká republika
IČ: 62026216 DIČ: CZ62026216
Odběratel
Kontaktní údaje
FUBO Private Gym - Hradec Králové s.r.o.
E-mail: andax@centrum.cz
V Kopečku 169/14
Telefon: 777727754
500 03 Hradec Králové
Česká republika
IČ: 23761059
Datum vystavení: 30.09.2026 Datum zdan. plnění: 30.09.2026 Datum splatnosti: 18.10.2026
Bankovní účet Symbol Způsob platby: Převodem
2200810605/2010 variabilní: 20260038
K úhradě
konstantní:
IBAN: CZ42 2010 0000 0022 0081 0605 0308
SWIFT: FIOBCZPP 3 250,00 Kč
Fakturujeme Vám za dodané zboží či služby:
Označení dodávky Počet m. j. Cena za m.j. DPH % Bez DPH DPH Celkem
zajištění úklidu provozních prostor za sjednané
1,00 2 685,95 21 2 685,95 564,05 3 250,00
období - září
Dovolujeme si Vás upozornit, že v případě nedodržení data splatnosti uvedeného na faktuře Vám můžeme účtovat zákonný úrok z prodlení.
Sazba DPH Základ Výše DPH Celkem
21 % 2 685,95 Kč 564,05 Kč 3 250,00 Kč
Celkem 2 685,95 Kč 564,05 Kč 3 250,00 Kč
Celkem k úhradě: 3 250,00 Kč
Vytiskl(a): Jiří Hušek, 26.10.2026 Vystaveno v online fakturační službě iDoklad www.iDoklad.cz Strana 1/1`;
