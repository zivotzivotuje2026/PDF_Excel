import { describe, expect, it } from 'vitest';
import { CzechInvoiceStrategy } from '@/pipeline/parsing/strategies/czechInvoiceStrategy';
import { normalizeLines, normalizeText, analyzeTextBlocks } from '@/pipeline/textblocks/textBlockAnalyzer';
import { REAL_INVOICE_ANDAX_2026032, REAL_INVOICE_IDOKLAD_20260038 } from '@/pipeline/__tests__/fixtures/realInvoiceTexts';

function parseText(raw: string) {
  const text = normalizeText(raw);
  const lines = normalizeLines(text);
  return new CzechInvoiceStrategy().parse({ text, lines, blocks: analyzeTextBlocks(lines) });
}

describe('real invoice text: ANDAX 2026032 (text layer with spaced capitals, no party labels)', () => {
  const { data, ambiguities } = parseText(REAL_INVOICE_ANDAX_2026032);

  it('keeps the invoice number with its internal space', () => {
    expect(data.invoiceNumber).toBe('2026 032');
    expect(data.variableSymbol).toBe('2026032');
    expect(data.constantSymbol).toBe('308');
  });

  it('assigns the issuer and the customer to different companies', () => {
    expect(data.supplier).toMatchObject({ name: 'ANDAX s.r.o.', ico: '62026216', dic: 'CZ62026216' });
    expect(data.customer).toMatchObject({ name: 'FUBO Private Gym – Hradec Králové s.r.o.', ico: '23761059', dic: null });
    expect(data.customer.name).not.toBe(data.supplier.name);
  });

  it('reads dates including the Czech "V Praze dne" issue date', () => {
    expect(data.issueDate).toBe('2026-09-02');
    expect(data.taxDate).toBe('2026-08-31');
    expect(data.dueDate).toBe('2026-09-10');
  });

  it('reads the amount after "k úhradě" written with spaced separators', () => {
    expect(data.totalAmount).toBe(3500);
    expect(data.currency).toBe('CZK');
  });

  it('reads the wrapped item row without inventing a quantity', () => {
    expect(data.items).toHaveLength(1);
    expect(data.items[0]).toMatchObject({
      quantity: null,
      unitPrice: null,
      vatRate: 21,
      vatBase: 2892.56,
      vatAmount: 607.44,
      total: 3500,
    });
    expect(data.items[0].description).toContain('srpen');
  });

  it('flags the roles as derived and the missing quantity for review', () => {
    expect(ambiguities.some((item) => item.field === 'supplier' && item.severity === 'warning')).toBe(true);
    expect(ambiguities.some((item) => item.field === 'items[0].quantity')).toBe(false);
  });
});

describe('real invoice text: iDoklad 20260038 (labelled parties, table without quantity column header)', () => {
  const { data, ambiguities } = parseText(REAL_INVOICE_IDOKLAD_20260038);

  it('reads the invoice number and variable symbol', () => {
    expect(data.invoiceNumber).toBe('20260038');
    expect(data.variableSymbol).toBe('20260038');
  });

  it('keeps the labelled parties and drops contact lines from the customer name', () => {
    expect(data.supplier).toMatchObject({ name: 'ANDAX s.r.o.', ico: '62026216', dic: 'CZ62026216' });
    expect(data.customer.name).toBe('FUBO Private Gym - Hradec Králové s.r.o.');
    expect(data.customer.ico).toBe('23761059');
    expect(data.customer.address).not.toMatch(/@|Telefon/);
  });

  it('reads all three dates including "Datum zdan. plnění"', () => {
    expect(data.issueDate).toBe('2026-09-30');
    expect(data.taxDate).toBe('2026-09-30');
    expect(data.dueDate).toBe('2026-10-18');
  });

  it('reads the total from "Celkem k úhradě"', () => {
    expect(data.totalAmount).toBe(3250);
    expect(data.currency).toBe('CZK');
  });

  it('reads the item row, including its description from the line above', () => {
    expect(data.items).toHaveLength(1);
    expect(data.items[0]).toMatchObject({
      quantity: 1,
      unitPrice: 2685.95,
      vatRate: 21,
      vatBase: 2685.95,
      vatAmount: 564.05,
      total: 3250,
    });
    expect(data.items[0].description).toContain('zajištění úklidu');
  });

  it('reads the VAT summary', () => {
    expect(data.vatSummary).toEqual([{ vatRate: 21, vatBase: 2685.95, vatAmount: 564.05 }]);
  });

  it('reports no error-level ambiguities', () => {
    expect(ambiguities.filter((item) => item.severity === 'error')).toEqual([]);
  });
});
