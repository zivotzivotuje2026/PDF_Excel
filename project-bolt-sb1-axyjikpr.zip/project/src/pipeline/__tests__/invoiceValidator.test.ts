import { describe, expect, it } from 'vitest';
import type { Ambiguity } from '@/types/invoice';
import type { ExtractedInvoice } from '@/pipeline/parsing/invoiceParser';
import { buildAmbiguities, validateInvoice } from '@/pipeline/validation/invoiceValidator';

function completeInvoice(): ExtractedInvoice {
  return {
    invoiceNumber: 'FV1',
    variableSymbol: 'FV1',
    constantSymbol: null,
    supplier: { name: 'Alfa s.r.o.', ico: '12345678', dic: 'CZ12345678', address: null },
    customer: { name: 'Beta a.s.', ico: null, dic: null, address: null },
    issueDate: '2024-03-01',
    taxDate: null,
    dueDate: '2024-03-31',
    items: [
      {
        description: 'Konzultace',
        quantity: 2,
        unitPrice: 500,
        vatRate: 21,
        vatBase: 1000,
        vatAmount: 210,
        total: 1210,
      },
    ],
    vatSummary: [{ vatRate: 21, vatBase: 1000, vatAmount: 210 }],
    totalAmount: 1210,
    currency: 'CZK',
  };
}

describe('validateInvoice', () => {
  it('reports nothing for a consistent invoice', () => {
    expect(validateInvoice(completeInvoice())).toEqual([]);
  });

  it('flags a missing invoice number and total as errors', () => {
    const invoice = { ...completeInvoice(), invoiceNumber: null, totalAmount: null };
    const issues = validateInvoice(invoice);
    expect(issues).toContainEqual(expect.objectContaining({ field: 'invoiceNumber', severity: 'error' }));
    expect(issues).toContainEqual(expect.objectContaining({ field: 'totalAmount', severity: 'error' }));
  });

  it('flags an item whose base and VAT do not add up to its total', () => {
    const invoice = completeInvoice();
    invoice.items[0] = { ...invoice.items[0], total: 1300 };
    expect(validateInvoice(invoice)).toContainEqual(
      expect.objectContaining({ field: 'items[0].total', severity: 'warning' }),
    );
  });

  it('flags a missing item quantity', () => {
    const invoice = completeInvoice();
    invoice.items[0] = { ...invoice.items[0], quantity: null };
    expect(validateInvoice(invoice)).toContainEqual(
      expect.objectContaining({ field: 'items[0].quantity', severity: 'warning' }),
    );
  });
});

describe('buildAmbiguities', () => {
  it('keeps parser ambiguities and replaces earlier validation output', () => {
    const parserItem: Ambiguity = { field: 'vatSummary', message: 'x', severity: 'info', source: 'parser' };
    const staleValidation: Ambiguity = { field: 'old', message: 'y', severity: 'warning', source: 'validation' };
    const result = buildAmbiguities(completeInvoice(), [parserItem, staleValidation]);
    expect(result).toEqual([parserItem]);
  });
});
