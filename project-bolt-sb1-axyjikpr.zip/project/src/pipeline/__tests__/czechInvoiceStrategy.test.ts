import { describe, expect, it } from 'vitest';
import { CzechInvoiceStrategy } from '@/pipeline/parsing/strategies/czechInvoiceStrategy';
import { analyzeTextBlocks } from '@/pipeline/textblocks/textBlockAnalyzer';

const SAMPLE_INVOICE = [
  'Faktura - daňový doklad',
  'Číslo faktury: FV-2024-0042',
  'Variabilní symbol: 2024042',
  'Konstantní symbol: 308',
  'Dodavatel',
  'Alfa Software s.r.o.',
  'Hlavní 1, 110 00 Praha',
  'IČO: 12345678',
  'DIČ: CZ12345678',
  'Odběratel',
  'Beta Trade a.s.',
  'Dlouhá 5, 602 00 Brno',
  'IČO: 87654321',
  'Datum vystavení: 1.3.2024',
  'Datum zdanitelného plnění: 1.3.2024',
  'Datum splatnosti: 31.3.2024',
  'Popis Množství MJ Cena DPH Celkem',
  'Konzultace 2 h 500,00 1 000,00 21 % 210,00 1 210,00',
  'Sazba DPH Základ DPH',
  '21 % 1 000,00 210,00',
  'Celkem 1 210,00 Kč',
  'K úhradě 1 210,00 Kč',
].join('\n');

describe('CzechInvoiceStrategy on a synthetic invoice', () => {
  const strategy = new CzechInvoiceStrategy();
  const lines = SAMPLE_INVOICE.split('\n');

  it('scores a Czech invoice above the parser threshold', () => {
    expect(strategy.canParse({ text: SAMPLE_INVOICE, lines, blocks: analyzeTextBlocks(lines) })).toBeGreaterThan(0.5);
  });

  it('extracts the header identifiers, dates and totals', () => {
    const { data } = strategy.parse({ text: SAMPLE_INVOICE, lines, blocks: analyzeTextBlocks(lines) });
    expect(data.invoiceNumber).toBe('FV-2024-0042');
    expect(data.variableSymbol).toBe('2024042');
    expect(data.constantSymbol).toBe('308');
    expect(data.issueDate).toBe('2024-03-01');
    expect(data.taxDate).toBe('2024-03-01');
    expect(data.dueDate).toBe('2024-03-31');
    expect(data.totalAmount).toBe(1210);
    expect(data.currency).toBe('CZK');
  });

  it('extracts the line item and VAT summary', () => {
    const { data } = strategy.parse({ text: SAMPLE_INVOICE, lines, blocks: analyzeTextBlocks(lines) });
    expect(data.items).toHaveLength(1);
    expect(data.items[0]).toMatchObject({ quantity: 2, unitPrice: 500, vatBase: 1000, vatAmount: 210, total: 1210 });
    expect(data.vatSummary).toEqual([{ vatRate: 21, vatBase: 1000, vatAmount: 210 }]);
  });

  it('reports no error-level ambiguities', () => {
    const { ambiguities } = strategy.parse({ text: SAMPLE_INVOICE, lines, blocks: analyzeTextBlocks(lines) });
    expect(ambiguities.filter((item) => item.severity === 'error')).toEqual([]);
  });
});
