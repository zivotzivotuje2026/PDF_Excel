import { describe, expect, it } from 'vitest';
import { extractNumbers, parseCzechNumber } from '@/pipeline/parsing/amountParser';
import { DATE_LABELS, findDateCandidates, findDatesInText, toIsoDate } from '@/pipeline/parsing/dateExtractor';
import { extractDic, extractIco, extractIdentifierCandidates } from '@/pipeline/parsing/identifierExtractor';
import { isVatConsistent, parseRate, parseVatSummary } from '@/pipeline/parsing/vatAnalyzer';
import { extractItems, parseItemLine } from '@/pipeline/parsing/itemExtractor';

describe('parseCzechNumber', () => {
  it.each([
    ['1 234,50', 1234.5],
    ['1.234,56', 1234.56],
    ['1,234.56', 1234.56],
    ['1.234', 1234],
    ['12,5', 12.5],
    ['1\u00a0210,00', 1210],
  ])('parses %s as %d', (raw, expected) => {
    expect(parseCzechNumber(raw)).toBe(expected);
  });

  it('returns null for non-numeric input', () => {
    expect(parseCzechNumber('abc')).toBeNull();
  });
});

describe('extractNumbers', () => {
  it('reads grouped amounts and plain numbers from a line', () => {
    expect(extractNumbers('Celkem 1 210,00 Kč DPH 21 %')).toEqual([1210, 21]);
  });
});

describe('dates', () => {
  it('finds Czech and ISO dates in document order', () => {
    expect(findDatesInText('Vystaveno 1.3.2024, splatnost 31. 3. 2024 a 2024-04-15')).toEqual([
      '2024-03-01',
      '2024-03-31',
      '2024-04-15',
    ]);
  });

  it('rejects impossible calendar dates', () => {
    expect(toIsoDate(2024, 2, 30)).toBeNull();
    expect(toIsoDate(2024, 2, 29)).toBe('2024-02-29');
  });

  it('takes the date from the next line when the label has none', () => {
    expect(findDateCandidates(['Datum vystavení', '1.3.2024'], DATE_LABELS.issueDate)).toEqual(['2024-03-01']);
  });

  it('separates the tax date label from the due date label', () => {
    const lines = ['Datum zdanitelného plnění: 1.3.2024', 'Datum splatnosti: 31.3.2024'];
    expect(findDateCandidates(lines, DATE_LABELS.taxDate)).toEqual(['2024-03-01']);
    expect(findDateCandidates(lines, DATE_LABELS.dueDate)).toEqual(['2024-03-31']);
  });
});

describe('identifiers', () => {
  it('distinguishes invoice number, variable symbol and constant symbol', () => {
    const text = 'Číslo faktury: FV-2024-0042\nVariabilní symbol: 2024042\nKS: 308';
    expect(extractIdentifierCandidates(text.split('\n'))).toEqual({
      invoiceNumbers: ['FV-2024-0042'],
      variableSymbols: ['2024042'],
      constantSymbols: ['308'],
    });
  });

  it('reads IČO with spaces inside the number', () => {
    expect(extractIco('IČO: 12 345 678')).toEqual(['12345678']);
  });

  it('reads DIČ with a country prefix', () => {
    expect(extractDic('DIČ: CZ12345678')).toEqual(['CZ12345678']);
  });
});

describe('VAT', () => {
  it('parses rate tokens with comma decimals', () => {
    expect(parseRate('21,5')).toBe(21.5);
  });

  it('reads the VAT summary rows after the header', () => {
    const lines = ['Sazba DPH Základ DPH', '21 % 1 000,00 210,00', '12 % 500 60'];
    expect(parseVatSummary(lines)).toEqual([
      { vatRate: 21, vatBase: 1000, vatAmount: 210 },
      { vatRate: 12, vatBase: 500, vatAmount: 60 },
    ]);
  });

  it('checks that VAT matches base times rate', () => {
    expect(isVatConsistent(1000, 21, 210)).toBe(true);
    expect(isVatConsistent(1000, 21, 200)).toBe(false);
  });
});

describe('items', () => {
  it('maps five trailing numbers to quantity, price, base, VAT and total', () => {
    expect(parseItemLine('Konzultace 2 h 500,00 1 000,00 21 % 210,00 1 210,00')).toEqual({
      description: 'Konzultace',
      quantity: 2,
      unitPrice: 500,
      vatRate: 21,
      vatBase: 1000,
      vatAmount: 210,
      total: 1210,
    });
  });

  it('returns null for a line without amounts', () => {
    expect(parseItemLine('Poznámka k objednávce')).toBeNull();
  });

  it('extracts only the rows between the item header and the totals', () => {
    const lines = [
      'Popis Množství MJ Cena DPH Celkem',
      'Konzultace 2 h 500,00 1 000,00 21 % 210,00 1 210,00',
      'Celkem 1 210,00 Kč',
      'Neměla by být položka',
    ];
    expect(extractItems(lines)).toHaveLength(1);
  });
});
