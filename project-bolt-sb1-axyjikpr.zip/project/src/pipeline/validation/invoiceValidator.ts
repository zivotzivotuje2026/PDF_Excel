import type { Ambiguity } from '@/types/invoice';
import { isVatConsistent } from '@/pipeline/parsing/vatAnalyzer';
import { isSameMoney, roundMoney } from '@/pipeline/parsing/amountParser';
import type { ExtractedInvoice } from '@/pipeline/parsing/invoiceParser';

const MONEY_TOLERANCE = 1;

export function buildAmbiguities(data: ExtractedInvoice, parserAmbiguities: Ambiguity[]): Ambiguity[] {
  return [...parserAmbiguities.filter((item) => item.source === 'parser'), ...validateInvoice(data)];
}

export function validateInvoice(data: ExtractedInvoice): Ambiguity[] {
  const issues: Ambiguity[] = [];
  const add = (field: string, message: string, severity: Ambiguity['severity']) =>
    issues.push({ field, message, severity, source: 'validation' });

  if (!data.invoiceNumber) add('invoiceNumber', 'Chybí číslo faktury.', 'error');
  if (!data.supplier.name) add('supplier', 'Chybí název dodavatele.', 'error');
  if (!data.supplier.ico) add('supplier.ico', 'Chybí IČO dodavatele.', 'warning');
  if (!data.supplier.dic) add('supplier.dic', 'Chybí DIČ dodavatele.', 'warning');
  if (!data.customer.name) add('customer', 'Chybí název odběratele.', 'warning');
  if (!data.issueDate) add('issueDate', 'Chybí datum vystavení.', 'warning');
  if (!data.dueDate) add('dueDate', 'Chybí datum splatnosti.', 'info');
  if (data.totalAmount === null) add('totalAmount', 'Chybí celková částka.', 'error');
  if (!data.currency) add('currency', 'Měna nebyla rozpoznána.', 'warning');

  data.items.forEach((item, index) => {
    const label = `Položka ${index + 1}${item.description ? ` (${item.description})` : ''}`;
    if (item.quantity === null) add(`items[${index}].quantity`, `${label}: chybí množství.`, 'warning');
    if (item.vatBase !== null && item.vatAmount !== null && item.total !== null &&
        !isSameMoney(roundMoney(item.vatBase + item.vatAmount), item.total, MONEY_TOLERANCE)) {
      add(`items[${index}].total`, `${label}: základ + DPH neodpovídá celkové ceně.`, 'warning');
    }
    if (item.quantity !== null && item.unitPrice !== null && item.vatBase !== null &&
        !isSameMoney(roundMoney(item.quantity * item.unitPrice), item.vatBase, MONEY_TOLERANCE)) {
      add(`items[${index}].vatBase`, `${label}: množství × cena neodpovídá základu.`, 'warning');
    }
    if (item.vatBase !== null && item.vatRate !== null && item.vatAmount !== null &&
        !isVatConsistent(item.vatBase, item.vatRate, item.vatAmount)) {
      add(`items[${index}].vatAmount`, `${label}: DPH neodpovídá sazbě ${item.vatRate} %.`, 'warning');
    }
  });

  if (data.items.length > 0 && data.totalAmount !== null) {
    const itemsTotal = roundMoney(data.items.reduce((sum, item) => sum + (item.total ?? 0), 0));
    if (!isSameMoney(itemsTotal, data.totalAmount, MONEY_TOLERANCE)) {
      add('totalAmount', `Součet položek (${itemsTotal}) neodpovídá celkové částce (${data.totalAmount}).`, 'warning');
    }
  }

  if (data.vatSummary.length > 0 && data.totalAmount !== null) {
    const summaryTotal = roundMoney(data.vatSummary.reduce((sum, row) => sum + row.vatBase + row.vatAmount, 0));
    if (!isSameMoney(summaryTotal, data.totalAmount, MONEY_TOLERANCE)) {
      add('vatSummary', 'Rekapitulace DPH neodpovídá celkové částce.', 'warning');
    }
  }

  return issues;
}
