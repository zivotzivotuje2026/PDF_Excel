export type DocumentKind = 'pdf' | 'image';

export interface IngestedDocument {
  file: File;
  kind: DocumentKind;
}

const MAX_FILE_BYTES = 20 * 1024 * 1024;

const KIND_BY_MIME: Record<string, DocumentKind> = {
  'application/pdf': 'pdf',
  'image/png': 'image',
  'image/jpeg': 'image',
  'image/webp': 'image',
};

export class IngestionError extends Error {}

export class FileIngestionService {
  ingest(file: File): IngestedDocument {
    const kind = KIND_BY_MIME[file.type];
    if (!kind) {
      throw new IngestionError('Nepodporovaný typ souboru. Nahrajte PDF, PNG, JPG nebo WEBP.');
    }
    if (file.size === 0) {
      throw new IngestionError('Soubor je prázdný.');
    }
    if (file.size > MAX_FILE_BYTES) {
      throw new IngestionError('Soubor je větší než 20 MB.');
    }
    return { file, kind };
  }
}
