import { valuesAfterLabel } from '@/pipeline/parsing/labelValues';

const DATE_PATTERNS: { re: RegExp; order: 'dmy' | 'ymd' }[] = [
  { re: /(?<!\d)(\d{1,2})\s?\.\s?(\d{1,2})\s?\.\s?(\d{4})(?!\d)/g, order: 'dmy' },
  { re: /(?<!\d)(\d{1,2})\/(\d{1,2})\/(\d{4})(?!\d)/g, order: 'dmy' },
  { re: /(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)/g, order: 'ymd' },
];

export const DATE_LABELS = {
  issueDate: /datum\s+vystaven[íi]|vystaveno|v\s+\p{L}+\s+dne|date\s+of\s+issue|issue\s+date/iu,
  taxDate: /datum\s+uskute[čc]n[ěe]n[íi]|zdan\.?\s+pln[ěe]n[íi]|zdaniteln[ée]ho\s+pln[ěe]n[íi]|duzp|tax\s+date/iu,
  dueDate: /datum\s+splatnosti|splatnost|due\s+date/iu,
} as const;

export function toIsoDate(year: number, month: number, day: number): string | null {
  const date = new Date(Date.UTC(year, month - 1, day));
  if (date.getUTCFullYear() !== year || date.getUTCMonth() !== month - 1 || date.getUTCDate() !== day) {
    return null;
  }
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function findDatesInText(text: string): string[] {
  const found: { index: number; iso: string }[] = [];
  for (const { re, order } of DATE_PATTERNS) {
    for (const match of text.matchAll(re)) {
      const [a, b, c] = match.slice(1).map(Number);
      const iso = order === 'dmy' ? toIsoDate(c, b, a) : toIsoDate(a, b, c);
      if (iso) found.push({ index: match.index ?? 0, iso });
    }
  }
  return found.sort((x, y) => x.index - y.index).map((entry) => entry.iso);
}

export function stripDates(text: string): string {
  return text.replace(/\d{1,2}\s?[./]\s?\d{1,2}\s?[./]\s?\d{4}|\d{4}-\d{2}-\d{2}/g, ' ');
}

export function findDateCandidates(lines: string[], label: RegExp): string[] {
  return valuesAfterLabel(lines, label, (text) => findDatesInText(text)[0] ?? null);
}
