import type { Ambiguity, Party } from '@/types/invoice';
import { extractDic, extractIco } from '@/pipeline/parsing/identifierExtractor';

const SUPPLIER_LABEL = /^(dodavatel|prodávající|poskytovatel|vystavil)\b/iu;
const CUSTOMER_LABEL = /^(odběratel|odberatel|kupující|zákazník|zakaznik|příjemce|objednatel)\b/iu;
const SECTION_STOP = /^(datum|číslo|faktura|variabiln|konstantn|položk|popis|celkem|k\s+úhradě|platba|bankovní|způsob)/iu;
const BANK_LINE = /IBAN|SWIFT|BIC\b|účet|banka/iu;
const NON_PARTY_LINE = /^(kontakt|e-?mail|telefon|tel\.?|fax|www|http|česká\s+republika|údaje|symbol)|@|https?:|www\./iu;
const LEGAL_FORM = /\b(s\s*\.\s*r\s*\.\s*o|a\s*\.\s*s|spol\.|v\s*\.\s*o\s*\.\s*s|k\s*\.\s*s|o\s*\.\s*p\s*\.\s*s)(?!\p{L})/iu;
const NOT_VAT_PAYER = /není\s+plátce\s+DPH/iu;
const IDENTIFIER_SEGMENT = /(?<![\p{L}])DI[ČC]\s*[:.]?\s*(?:CZ|SK)?\s?\d[\d ]*|(?<![\p{L}])I[ČC]O?\s*[:.]?\s*\d[\d ]*/giu;
const MAX_REGION_LINES = 8;
const NAME_SEARCH_DEPTH = 4;

export interface PartyClassification {
  supplier: Party;
  customer: Party;
  ambiguities: Ambiguity[];
}

interface PartyCandidate {
  party: Party;
  score: number;
  index: number;
}

export function classifyParties(lines: string[]): PartyClassification {
  const labelledSupplier = labelledParty(lines, SUPPLIER_LABEL);
  const labelledCustomer = labelledParty(lines, CUSTOMER_LABEL);
  const ranked = rankCandidates(companyCandidates(lines));
  const ambiguities: Ambiguity[] = [];

  let supplier = labelledSupplier;
  let customer = labelledCustomer;

  if (!supplier && !customer) {
    supplier = ranked[0]?.party ?? null;
    customer = ranked.find((candidate) => candidate.party.ico !== supplier?.ico)?.party ?? null;
    if (ranked.length >= 2 && ranked[0].score === ranked[1].score) {
      ambiguities.push({
        field: 'supplier',
        message: 'Role dodavatele a odběratele nelze jednoznačně určit, zkontrolujte přiřazení stran.',
        severity: 'warning',
        source: 'parser',
      });
    }
  } else if (!supplier) {
    supplier = ranked.find((candidate) => candidate.party.ico !== customer?.ico)?.party ?? null;
  } else if (!customer) {
    customer = ranked.find((candidate) => candidate.party.ico !== supplier?.ico)?.party ?? null;
  }

  if (!labelledSupplier || !labelledCustomer) {
    ambiguities.push({
      field: 'supplier',
      message: 'Strany faktury nejsou označené jednoznačně, role dodavatele a odběratele byla odvozena z IČO a DIČ.',
      severity: 'warning',
      source: 'parser',
    });
  }
  if (!supplier) {
    ambiguities.push({ field: 'supplier', message: 'Dodavatel nebyl v dokumentu rozpoznán.', severity: 'warning', source: 'parser' });
  }
  if (!customer) {
    ambiguities.push({ field: 'customer', message: 'Odběratel nebyl v dokumentu rozpoznán.', severity: 'warning', source: 'parser' });
  }

  return {
    supplier: supplier ?? emptyParty(),
    customer: customer ?? emptyParty(),
    ambiguities,
  };
}

function labelledParty(lines: string[], label: RegExp): Party | null {
  const index = lines.findIndex((line) => label.test(line));
  if (index < 0) return null;
  return toParty(regionFromLabel(lines, index));
}

function regionFromLabel(lines: string[], labelIndex: number): string[] {
  const region: string[] = [];
  const inlineValue = lines[labelIndex].replace(/^[^\s:]+\s*:?\s*/, '');
  if (inlineValue) region.push(inlineValue);

  for (let index = labelIndex + 1; index < lines.length && region.length < MAX_REGION_LINES; index++) {
    const line = lines[index];
    if (SUPPLIER_LABEL.test(line) || CUSTOMER_LABEL.test(line) || SECTION_STOP.test(line)) break;
    region.push(line);
  }
  return region;
}

function companyCandidates(lines: string[]): PartyCandidate[] {
  const seen = new Set<string>();
  const candidates: PartyCandidate[] = [];

  lines.forEach((line, index) => {
    const ico = extractIco(line)[0] ?? null;
    const dic = extractDic(line)[0] ?? null;
    if (!ico && !dic) return;

    const key = ico ?? dic?.replace(/\D/g, '') ?? '';
    if (seen.has(key)) return;
    seen.add(key);

    const nearby = lines.slice(Math.max(0, index - 1), index + 3).join('\n');
    const nameLines = nameLinesBefore(lines, index);
    const party = toParty(nameLines, {
      ico: ico ?? extractIco(nearby)[0] ?? null,
      dic: extractDic(lines.slice(index, index + 3).join('\n'))[0] ?? null,
    });
    const score = (party.dic ? 2 : 0) - (NOT_VAT_PAYER.test(nearby) ? 2 : 0);
    candidates.push({ party, score, index });
  });

  return candidates;
}

function nameLinesBefore(lines: string[], index: number): string[] {
  for (let cursor = index - 1; cursor >= Math.max(0, index - NAME_SEARCH_DEPTH); cursor--) {
    if (!LEGAL_FORM.test(lines[cursor])) continue;
    const start = cursor > 0 && /[–-]\s*$/.test(lines[cursor - 1]) ? cursor - 1 : cursor;
    return lines.slice(start, index);
  }
  return lines.slice(Math.max(0, index - 2), index);
}

function rankCandidates(candidates: PartyCandidate[]): PartyCandidate[] {
  return [...candidates].sort((a, b) => b.score - a.score || a.index - b.index);
}

function toParty(region: string[], identifiers?: { ico: string | null; dic: string | null }): Party {
  const text = region.join('\n');
  const ico = identifiers?.ico ?? extractIco(text)[0] ?? null;
  const dic = identifiers?.dic ?? extractDic(text)[0] ?? null;
  const content = region
    .filter((line) => !BANK_LINE.test(line) && !NON_PARTY_LINE.test(line))
    .map((line) => line.replace(IDENTIFIER_SEGMENT, '').replace(/\s{2,}/g, ' ').trim())
    .filter((line) => /\p{L}/u.test(line));
  const merged = content.length > 1 && /[–-]$/.test(content[0]) ? [`${content[0]} ${content[1]}`, ...content.slice(2)] : content;
  return {
    name: merged[0] ? normalizeLegalForm(merged[0]) : null,
    ico,
    dic,
    address: merged.slice(1).join(', ') || null,
  };
}

function normalizeLegalForm(name: string): string {
  return name
    .replace(/s\s*\.\s*r\s*\.\s*o\s*\./giu, 's.r.o.')
    .replace(/a\s*\.\s*s\s*\./giu, 'a.s.')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function emptyParty(): Party {
  return { name: null, ico: null, dic: null, address: null };
}
