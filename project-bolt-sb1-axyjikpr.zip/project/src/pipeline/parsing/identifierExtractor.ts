import { distinct, valuesAfterLabel } from '@/pipeline/parsing/labelValues';

export interface IdentifierCandidates {
  invoiceNumbers: string[];
  variableSymbols: string[];
  constantSymbols: string[];
}

const INVOICE_NUMBER_LABEL =
  /číslo\s+faktury|číslo\s+dokladu|faktura\s+č\.?|doklad\s+č\.?|faktura\s*[-–−]\s*daňov[ýy]\s*doklad(?:\s*č\.?)?|daňov[ýy]\s*doklad(?:\s*č\.?)?/iu;
const INVOICE_NUMBER_VALUE = /^([A-Z0-9][A-Z0-9/_-]*(?:\s\d{3,4}(?!\d))*)/iu;
const VARIABLE_SYMBOL_LABEL = /variabiln[íi](?:\s+symbol)?|var\.\s*symbol|\bVS\b/iu;
const CONSTANT_SYMBOL_LABEL = /konstantn[íi](?:\s+symbol)?|\bKS\b/iu;
const SYMBOL_VALUE = /^(\d{1,10})(?!\d)/;

const ICO = /(?<!\p{L})I[ČC]O?\s*[:.]?\s*(\d(?:\s?\d){7})(?!\d)/giu;
const DIC = /(?<!\p{L})DI[ČC]\s*[:.]?\s*((?:CZ|SK)?\s?\d{8,10})(?!\d)/giu;

export function extractIdentifierCandidates(lines: string[]): IdentifierCandidates {
  return {
    invoiceNumbers: distinct(valuesAfterLabel(lines, INVOICE_NUMBER_LABEL, extractInvoiceNumber)),
    variableSymbols: distinct(valuesAfterLabel(lines, VARIABLE_SYMBOL_LABEL, (text) => SYMBOL_VALUE.exec(text)?.[1] ?? null)),
    constantSymbols: distinct(valuesAfterLabel(lines, CONSTANT_SYMBOL_LABEL, (text) => SYMBOL_VALUE.exec(text)?.[1] ?? null)),
  };
}

function extractInvoiceNumber(text: string): string | null {
  const value = INVOICE_NUMBER_VALUE.exec(text)?.[1].trim() ?? null;
  return value && /\d/.test(value) ? value : null;
}

export function extractIco(text: string): string[] {
  return distinct([...text.matchAll(ICO)].map((match) => match[1].replace(/\s/g, '')));
}

export function extractDic(text: string): string[] {
  return distinct([...text.matchAll(DIC)].map((match) => match[1].replace(/\s/g, '')));
}
