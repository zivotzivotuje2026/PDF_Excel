import type { Ambiguity, VatSummaryRow } from '@/types/invoice';
import { extractMoneyAmounts } from '@/pipeline/parsing/amountParser';
import { DATE_LABELS, findDateCandidates, stripDates } from '@/pipeline/parsing/dateExtractor';
import { extractIdentifierCandidates } from '@/pipeline/parsing/identifierExtractor';
import { classifyParties } from '@/pipeline/parsing/partyClassifier';
import { extractItems } from '@/pipeline/parsing/itemExtractor';
import { parseVatSummary } from '@/pipeline/parsing/vatAnalyzer';
import { valuesAfterLabel, distinct } from '@/pipeline/parsing/labelValues';
import type { IInvoiceParserStrategy, ParseContext, ParseResult } from '@/pipeline/parsing/invoiceParser';

const PAYABLE_LABEL = /celkem\s+k\s+úhradě|k\s+úhradě|k\s+zaplacení/iu;
const TOTAL_LABEL = /celkem|celkov[áa]\s+částka/iu;
const CURRENCY_CODE = /\b(CZK|EUR|USD|GBP|PLN)\b/;
const CZECH_CROWN = /Kč/;
const INVOICE_HINT = /faktur|daňov[ýy]\s+doklad|invoice/iu;
const CZECH_TAX_HINT = /DPH|DIČ|IČO?/u;

export class CzechInvoiceStrategy implements IInvoiceParserStrategy {
  readonly id = 'czech-generic';

  canParse({ text }: ParseContext): number {
    let score = 0;
    if (INVOICE_HINT.test(text)) score += 0.5;
    if (CZECH_TAX_HINT.test(text)) score += 0.3;
    if (/\d{8}/.test(text)) score += 0.2;
    return Math.min(score, 1);
  }

  parse({ text, lines }: ParseContext): ParseResult {
    const ambiguities: Ambiguity[] = [];
    const identifiers = extractIdentifierCandidates(lines);

    const { invoiceNumber, variableSymbol } = pickInvoiceNumber(identifiers, ambiguities);
    const constantSymbol = pickSingle('constantSymbol', identifiers.constantSymbols, 'Konstantní symbol', ambiguities);

    const parties = classifyParties(lines);
    ambiguities.push(...parties.ambiguities);

    const issueDate = pickDate('issueDate', findDateCandidates(lines, DATE_LABELS.issueDate), 'Datum vystavení', ambiguities);
    const taxDate = pickDate('taxDate', findDateCandidates(lines, DATE_LABELS.taxDate), 'Datum zdanitelného plnění', ambiguities);
    const dueDate = pickDate('dueDate', findDateCandidates(lines, DATE_LABELS.dueDate), 'Datum splatnosti', ambiguities);

    const totalAmount = pickTotal(lines, ambiguities);
    const currency = detectCurrency(lines, text);
    const items = extractItems(lines);
    if (items.length === 0) {
      ambiguities.push({
        field: 'items',
        message: 'Položky faktury nebyly v dokumentu nalezeny.',
        severity: 'warning',
        source: 'parser',
      });
    }
    const vatSummary: VatSummaryRow[] = parseVatSummary(lines);

    return {
      data: {
        invoiceNumber,
        variableSymbol,
        constantSymbol,
        supplier: parties.supplier,
        customer: parties.customer,
        issueDate,
        taxDate,
        dueDate,
        items,
        vatSummary,
        totalAmount,
        currency,
      },
      ambiguities,
    };
  }
}

function pickInvoiceNumber(
  identifiers: ReturnType<typeof extractIdentifierCandidates>,
  ambiguities: Ambiguity[],
): { invoiceNumber: string | null; variableSymbol: string | null } {
  const variableSymbol = pickSingle('variableSymbol', identifiers.variableSymbols, 'Variabilní symbol', ambiguities);
  const [primary] = identifiers.invoiceNumbers;

  if (primary) {
    if (identifiers.invoiceNumbers.length > 1) {
      ambiguities.push({
        field: 'invoiceNumber',
        message: `Nalezeno více kandidátů na číslo faktury: ${identifiers.invoiceNumbers.join(', ')}.`,
        severity: 'warning',
        source: 'parser',
      });
    }
    return { invoiceNumber: primary, variableSymbol };
  }

  ambiguities.push({
    field: 'invoiceNumber',
    message: 'Číslo faktury nebylo nalezeno.',
    severity: 'error',
    source: 'parser',
  });
  return { invoiceNumber: null, variableSymbol };
}

function pickSingle(field: string, candidates: string[], label: string, ambiguities: Ambiguity[]): string | null {
  if (candidates.length > 1) {
    ambiguities.push({
      field,
      message: `${label}: nalezeno více hodnot (${candidates.join(', ')}).`,
      severity: 'warning',
      source: 'parser',
    });
  }
  return candidates[0] ?? null;
}

function pickDate(field: string, candidates: string[], label: string, ambiguities: Ambiguity[]): string | null {
  const distinctDates = distinct(candidates);
  if (distinctDates.length > 1) {
    ambiguities.push({
      field,
      message: `${label}: nalezeno více kandidátů (${distinctDates.join(', ')}).`,
      severity: 'warning',
      source: 'parser',
    });
  }
  return distinctDates[0] ?? null;
}

function lastAmount(text: string): number | null {
  const amounts = extractMoneyAmounts(stripDates(text));
  return amounts[amounts.length - 1] ?? null;
}

function pickTotal(lines: string[], ambiguities: Ambiguity[]): number | null {
  const payable = valuesAfterLabel(lines, PAYABLE_LABEL, lastAmount);
  const candidates = payable.length > 0 ? payable : valuesAfterLabel(lines, TOTAL_LABEL, lastAmount);
  const distinctAmounts = distinct(candidates);

  if (distinctAmounts.length > 1) {
    ambiguities.push({
      field: 'totalAmount',
      message: `Celková částka: nalezeno více hodnot (${distinctAmounts.join(', ')}), použita poslední.`,
      severity: 'warning',
      source: 'parser',
    });
  }
  return candidates[candidates.length - 1] ?? null;
}

function detectCurrency(lines: string[], text: string): string | null {
  const totalLine = lines.find((line) => PAYABLE_LABEL.test(line) || TOTAL_LABEL.test(line)) ?? '';
  const code = (CURRENCY_CODE.exec(totalLine) ?? CURRENCY_CODE.exec(text))?.[1];
  if (code) return code;
  if (CZECH_CROWN.test(totalLine) || CZECH_CROWN.test(text)) return 'CZK';
  return null;
}
