import type { Ambiguity, InvoiceData } from '@/types/invoice';
import type { TextBlock } from '@/pipeline/textblocks/textBlockAnalyzer';

export interface ParseContext {
  text: string;
  lines: string[];
  blocks: TextBlock[];
}

export type ExtractedInvoice = Omit<InvoiceData, 'ambiguities'>;

export interface ParseResult {
  data: ExtractedInvoice;
  ambiguities: Ambiguity[];
}

export interface IInvoiceParserStrategy {
  readonly id: string;
  canParse(context: ParseContext): number;
  parse(context: ParseContext): ParseResult;
}

export class InvoiceParser {
  constructor(private readonly strategies: IInvoiceParserStrategy[]) {}

  parse(context: ParseContext): ParseResult {
    const [best] = this.strategies
      .map((strategy) => ({ strategy, score: strategy.canParse(context) }))
      .sort((a, b) => b.score - a.score);

    if (!best || best.score <= 0) {
      throw new Error('Typ faktury se nepodařilo rozpoznat.');
    }
    return best.strategy.parse(context);
  }
}
