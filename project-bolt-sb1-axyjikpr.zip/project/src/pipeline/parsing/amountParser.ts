export const AMOUNT_TOKEN = /-?\d{1,3}(?:[ \u00a0\u202f]\d{3})+(?:[.,]\d{1,2})?(?!\d)|-?\d+(?:[.,]\d{1,2})?(?!\d)/g;

const NUMBER_SHAPE = /^-?\d[\d.,]*$/;
const THOUSANDS_DOTTED = /^-?\d{1,3}(\.\d{3})+$/;

export function parseCzechNumber(raw: string): number | null {
  const compact = raw.replace(/[\s\u00a0\u202f]/g, '');
  if (!NUMBER_SHAPE.test(compact)) return null;

  let normalized = compact;
  const lastComma = compact.lastIndexOf(',');
  const lastDot = compact.lastIndexOf('.');

  if (lastComma !== -1 && lastDot !== -1) {
    normalized =
      lastComma > lastDot
        ? compact.replace(/\./g, '').replace(',', '.')
        : compact.replace(/,/g, '');
  } else if (lastComma !== -1) {
    normalized = compact.replace(',', '.');
  } else if (THOUSANDS_DOTTED.test(compact)) {
    normalized = compact.replace(/\./g, '');
  }

  const value = Number(normalized);
  return Number.isFinite(value) ? value : null;
}

export function extractNumbers(text: string): number[] {
  const values: number[] = [];
  for (const match of text.matchAll(AMOUNT_TOKEN)) {
    const value = parseCzechNumber(match[0]);
    if (value !== null) values.push(value);
  }
  return values;
}

const MONEY_WITH_DECIMALS = /(?<![\d.,])-?\d{1,3}(?:[ \u00a0\u202f.]?\d{3})*[.,]\d{2}(?!\d)/g;

export function normalizeNumberSeparators(text: string): string {
  return text.replace(/(\d)\s+([.,])/g, '$1$2').replace(/([.,])\s+(\d)/g, '$1$2');
}

export function extractMoneyAmounts(text: string): number[] {
  const values: number[] = [];
  for (const match of normalizeNumberSeparators(text).matchAll(MONEY_WITH_DECIMALS)) {
    const value = parseCzechNumber(match[0]);
    if (value !== null) values.push(value);
  }
  return values;
}

export function roundMoney(value: number): number {
  return Math.round(value * 100) / 100;
}

export function isSameMoney(a: number, b: number, tolerance = 1): boolean {
  return Math.abs(a - b) <= tolerance;
}
