const LABEL_SEPARATOR = /^[\s:.=]+/;

export function valuesAfterLabel<T>(lines: string[], label: RegExp, extract: (text: string) => T | null): T[] {
  const values: T[] = [];
  lines.forEach((line, index) => {
    const match = label.exec(line);
    if (!match) return;

    const rest = line.slice(match.index + match[0].length).replace(LABEL_SEPARATOR, '').trim();
    const source = rest || lines[index + 1]?.trim() || '';
    const value = extract(source);
    if (value !== null) values.push(value);
  });
  return values;
}

export function distinct<T>(values: T[]): T[] {
  return [...new Set(values)];
}
