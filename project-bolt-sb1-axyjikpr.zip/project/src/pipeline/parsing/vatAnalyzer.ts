import type { VatSummaryRow } from '@/types/invoice';
import { extractNumbers, isSameMoney, roundMoney } from '@/pipeline/parsing/amountParser';

export const RATE_TOKEN = /(?<![\d.,])(\d{1,2}(?:[.,]\d)?)\s?%/;
const SUMMARY_HEADER = /sazba\s+dph|rekapitulace|základ\s+dph/iu;

export function parseRate(token: string): number | null {
  const value = Number(token.replace(',', '.'));
  return Number.isFinite(value) ? value : null;
}

export function parseVatSummary(lines: string[]): VatSummaryRow[] {
  const headerIndex = lines.findIndex((line) => SUMMARY_HEADER.test(line));
  const scope = headerIndex >= 0 ? lines.slice(headerIndex + 1) : lines;
  const rows: VatSummaryRow[] = [];

  for (const line of scope) {
    const match = RATE_TOKEN.exec(line);
    if (!match) continue;
    const rate = parseRate(match[1]);
    const before = line.slice(0, match.index);
    const numbers = extractNumbers(line.slice(match.index + match[0].length));
    if (rate === null || /\d/.test(before) || numbers.length < 2 || numbers.length > 3) continue;
    rows.push({ vatRate: rate, vatBase: numbers[0], vatAmount: numbers[1] });
  }
  return rows;
}

export function isVatConsistent(base: number, rate: number, vat: number): boolean {
  return isSameMoney(roundMoney((base * rate) / 100), vat, 0.02);
}
