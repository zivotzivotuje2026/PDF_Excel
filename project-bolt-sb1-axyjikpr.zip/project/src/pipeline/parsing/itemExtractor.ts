import type { InvoiceItem } from '@/types/invoice';
import { parseCzechNumber, isSameMoney, roundMoney } from '@/pipeline/parsing/amountParser';
import { parseRate, isVatConsistent } from '@/pipeline/parsing/vatAnalyzer';

const ITEMS_HEADER = /(popis|název|položk|označen|předmět\s+plnění)/iu;
const ITEMS_COLUMNS = /(cena|částka|celkem|dph|množství|mj)/iu;
const ITEMS_END = /celkem|k\s+úhradě|k\s+zaplacení|rekapitulace|sazba\s+dph|základ\s+dph/iu;

const UNIT_TOKEN = /^(ks|kus|kusů|hod|h|m2|m²|m3|m|kg|g|l|bal|pár|den|dní|km|sada|mth|měs|lic\.?)\.?$/iu;
const CURRENCY_TOKEN = /^(kč|czk|eur|usd|€|\$)$/iu;
const PLAIN_NUMBER = /^-?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+|\.\d+)?$/;
const RATE_WORD = /^\d{1,2}(?:[.,]\d)?%$/;
const YEAR_TOKEN = /^(19|20)\d{2}$/;
const COMMON_VAT_RATES = [21, 15, 12, 10, 5, 0];
const MONEY_TOLERANCE = 0.05;
const CONTINUATION_MAX_LENGTH = 40;

export function extractItems(lines: string[]): InvoiceItem[] {
  const headerIndex = lines.findIndex((line) => ITEMS_HEADER.test(line) && ITEMS_COLUMNS.test(line));
  if (headerIndex < 0) return [];

  const items: InvoiceItem[] = [];
  let pending: string[] = [];
  for (const line of lines.slice(headerIndex + 1)) {
    const hasDigits = /\d/.test(line);
    if (ITEMS_END.test(line) && (items.length > 0 || hasDigits)) break;

    const item = parseItemLine(line);
    if (item) {
      const description = item.description || pending.slice(-2).join(' ');
      items.push({ ...item, description });
      pending = [];
      continue;
    }

    if (hasDigits) continue;
    const lastItem = items[items.length - 1];
    if (lastItem && pending.length === 0 && line.length <= CONTINUATION_MAX_LENGTH) {
      lastItem.description = `${lastItem.description} ${line}`.trim();
    } else {
      pending.push(line);
    }
  }
  return items;
}

export function parseItemLine(line: string): InvoiceItem | null {
  const normalized = line
    .replace(/(?<![\d,.])(\d{1,3})[ \u00a0\u202f](?=\d{3}(?!\d))/g, '$1')
    .replace(/(\d)\s?%/g, '$1%');
  const tokens = normalized.split(' ').filter(Boolean);

  const tail: string[] = [];
  let cursor = tokens.length - 1;
  while (cursor >= 0 && isTailToken(tokens[cursor])) {
    tail.unshift(tokens[cursor]);
    cursor--;
  }

  const descriptionParts = tokens.slice(0, cursor + 1);
  while (tail.length > 0 && YEAR_TOKEN.test(tail[0]) && numericTokens(tail).length > 3) {
    descriptionParts.push(tail.shift() as string);
  }

  const description = descriptionParts.join(' ').replace(/^\d+[.)]?\s+/, '').trim();
  const rateToken = tail.find((token) => RATE_WORD.test(token));
  const rate = rateToken ? parseRate(rateToken.replace('%', '')) : null;
  const numbers = numericTokens(tail);

  if (numbers.length < 1 || (numbers.length < 2 && rate === null)) return null;
  return assignItemNumbers(description, rate, numbers);
}

function numericTokens(tail: string[]): number[] {
  return tail
    .filter((token) => PLAIN_NUMBER.test(token))
    .map((token) => parseCzechNumber(token))
    .filter((value): value is number => value !== null);
}

function isTailToken(token: string): boolean {
  return PLAIN_NUMBER.test(token) || RATE_WORD.test(token) || token === '%' || UNIT_TOKEN.test(token) || CURRENCY_TOKEN.test(token);
}

function assignItemNumbers(description: string, rate: number | null, numbers: number[]): InvoiceItem {
  const solved = solveWithRate(description, rate, numbers);
  if (solved) return solved;

  const n = numbers.length;
  const base: InvoiceItem = {
    description,
    quantity: null,
    unitPrice: null,
    vatRate: rate,
    vatBase: null,
    vatAmount: null,
    total: null,
  };

  if (n >= 5) {
    return {
      ...base,
      quantity: numbers[n - 5],
      unitPrice: numbers[n - 4],
      vatBase: numbers[n - 3],
      vatAmount: numbers[n - 2],
      total: numbers[n - 1],
    };
  }
  if (n === 4) {
    return { ...base, unitPrice: numbers[0], vatBase: numbers[1], vatAmount: numbers[2], total: numbers[3] };
  }
  if (n === 3) {
    const looksLikeBaseVatTotal = rate !== null && isSameMoney(roundMoney((numbers[0] * rate) / 100), numbers[1], 0.02);
    if (looksLikeBaseVatTotal) {
      return { ...base, vatBase: numbers[0], vatAmount: numbers[1], total: numbers[2] };
    }
    return { ...base, unitPrice: numbers[0], vatBase: numbers[1], total: numbers[2] };
  }
  if (n === 2) {
    const total = numbers[1];
    if (rate === null) return { ...base, unitPrice: numbers[0], total };
    const vatBase = roundMoney(total / (1 + rate / 100));
    return { ...base, unitPrice: numbers[0], vatBase, vatAmount: roundMoney(total - vatBase), total };
  }
  return { ...base, total: numbers[0] };
}

function solveWithRate(description: string, explicitRate: number | null, numbers: number[]): InvoiceItem | null {
  const candidateRates = explicitRate !== null
    ? [explicitRate]
    : COMMON_VAT_RATES.filter((rate) => numbers.includes(rate));

  for (const rate of candidateRates) {
    const rest = [...numbers];
    if (explicitRate === null) rest.splice(rest.indexOf(rate), 1);
    if (rest.length < 3) continue;

    const [vatBase, vatAmount, total] = rest.slice(-3);
    const prefix = rest.slice(0, -3);
    const consistent =
      isSameMoney(roundMoney(vatBase + vatAmount), total, MONEY_TOLERANCE) &&
      isVatConsistent(vatBase, rate, vatAmount);
    if (!consistent) continue;

    const [quantity, unitPrice] = prefix.length >= 2
      ? [prefix[prefix.length - 2], prefix[prefix.length - 1]]
      : [null, prefix[0] ?? null];
    return { description, quantity, unitPrice, vatRate: rate, vatBase, vatAmount, total };
  }
  return null;
}
