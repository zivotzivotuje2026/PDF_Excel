import * as pdfjs from 'pdfjs-dist';
import type { PDFDocumentProxy, PDFPageProxy } from 'pdfjs-dist';
import pdfWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjs.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;

export async function openPdf(file: File): Promise<PDFDocumentProxy> {
  const data = new Uint8Array(await file.arrayBuffer());
  return pdfjs.getDocument({ data }).promise;
}

export async function extractTextLayer(pdf: PDFDocumentProxy): Promise<string> {
  const parts: string[] = [];
  for (let pageNumber = 1; pageNumber <= pdf.numPages; pageNumber++) {
    const page = await pdf.getPage(pageNumber);
    parts.push(await readPageText(page));
  }
  return parts.join('\n');
}

export async function renderPagesToPng(pdf: PDFDocumentProxy, maxPages: number, scale = 2): Promise<Blob[]> {
  const blobs: Blob[] = [];
  const count = Math.min(pdf.numPages, maxPages);
  for (let pageNumber = 1; pageNumber <= count; pageNumber++) {
    const page = await pdf.getPage(pageNumber);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width = Math.floor(viewport.width);
    canvas.height = Math.floor(viewport.height);
    const context = canvas.getContext('2d');
    if (!context) throw new Error('Nelze vytvořit grafické plátno pro OCR.');
    await page.render({ canvasContext: context, canvas, viewport }).promise;
    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/png'));
    if (!blob) throw new Error('Nelze převést stránku dokumentu na obrázek.');
    blobs.push(blob);
  }
  return blobs;
}

async function readPageText(page: PDFPageProxy): Promise<string> {
  const content = await page.getTextContent();
  const rows = new Map<number, { x: number; str: string }[]>();
  for (const item of content.items) {
    if (!('str' in item) || !item.str.trim()) continue;
    const y = Math.round(item.transform[5]);
    const row = rows.get(y) ?? [];
    row.push({ x: item.transform[4], str: item.str });
    rows.set(y, row);
  }
  return [...rows.entries()]
    .sort(([a], [b]) => b - a)
    .map(([, row]) =>
      row
        .sort((a, b) => a.x - b.x)
        .map((cell) => cell.str)
        .join(' '),
    )
    .join('\n');
}
