import type { IngestedDocument } from '@/pipeline/ingestion/fileIngestion';
import { extractTextLayer, openPdf, renderPagesToPng } from '@/pipeline/ocr/pdfDocument';
import type { IOcrProvider, ProgressCallback, TextExtraction } from '@/pipeline/ocr/ocrTypes';

const MIN_TEXT_LAYER_CHARS = 80;
const MAX_OCR_PAGES = 3;

export class OcrService {
  constructor(private readonly provider: IOcrProvider) {}

  async extractText({ file, kind }: IngestedDocument, onProgress?: ProgressCallback): Promise<TextExtraction> {
    if (kind === 'pdf') {
      return this.extractFromPdf(file, onProgress);
    }
    return { text: await this.provider.recognize(file, onProgress), method: 'ocr' };
  }

  private async extractFromPdf(file: File, onProgress?: ProgressCallback): Promise<TextExtraction> {
    const pdf = await openPdf(file);
    const textLayer = await extractTextLayer(pdf);
    if (countSignificantChars(textLayer) >= MIN_TEXT_LAYER_CHARS) {
      return { text: textLayer, method: 'pdf-text-layer' };
    }

    const pages = await renderPagesToPng(pdf, MAX_OCR_PAGES);
    const texts: string[] = [];
    for (const [index, page] of pages.entries()) {
      texts.push(
        await this.provider.recognize(page, (progress) =>
          onProgress?.({ stage: `Stránka ${index + 1}: ${progress.stage}`, ratio: progress.ratio }),
        ),
      );
    }
    return { text: texts.join('\n'), method: 'ocr' };
  }
}

function countSignificantChars(text: string): number {
  return text.replace(/\s/g, '').length;
}
