import { createWorker, type Worker } from 'tesseract.js';
import type { IOcrProvider, ProgressCallback } from '@/pipeline/ocr/ocrTypes';

export class TesseractOcrProvider implements IOcrProvider {
  readonly id = 'tesseract';
  private workerPromise: Promise<Worker> | null = null;
  private progressHandler: ProgressCallback | undefined;

  private getWorker(): Promise<Worker> {
    if (!this.workerPromise) {
      this.workerPromise = createWorker(['ces', 'eng'], undefined, {
        logger: (message) => {
          this.progressHandler?.({ stage: message.status, ratio: message.progress });
        },
      }).catch((error: unknown) => {
        this.workerPromise = null;
        throw error;
      });
    }
    return this.workerPromise;
  }

  async recognize(image: Blob, onProgress?: ProgressCallback): Promise<string> {
    const worker = await this.getWorker();
    this.progressHandler = onProgress;
    try {
      const { data } = await worker.recognize(image);
      return data.text;
    } finally {
      this.progressHandler = undefined;
    }
  }

  async dispose(): Promise<void> {
    if (!this.workerPromise) return;
    const worker = await this.workerPromise;
    this.workerPromise = null;
    await worker.terminate();
  }
}
