export interface OcrProgress {
  stage: string;
  ratio: number;
}

export type ProgressCallback = (progress: OcrProgress) => void;

export interface IOcrProvider {
  readonly id: string;
  recognize(image: Blob, onProgress?: ProgressCallback): Promise<string>;
  dispose?(): Promise<void>;
}

export interface TextExtraction {
  text: string;
  method: 'pdf-text-layer' | 'ocr';
}
