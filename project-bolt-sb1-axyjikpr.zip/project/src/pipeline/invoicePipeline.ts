import type { InvoiceData } from '@/types/invoice';
import type { ExtractedInvoice, InvoiceParser } from '@/pipeline/parsing/invoiceParser';
import { buildAmbiguities } from '@/pipeline/validation/invoiceValidator';
import { normalizeLines, normalizeText, analyzeTextBlocks } from '@/pipeline/textblocks/textBlockAnalyzer';
import type { FileIngestionService } from '@/pipeline/ingestion/fileIngestion';
import type { OcrService } from '@/pipeline/ocr/ocrService';
import type { ProgressCallback } from '@/pipeline/ocr/ocrTypes';

export interface ProcessedInvoice {
  data: InvoiceData;
  rawText: string;
  textSource: 'pdf-text-layer' | 'ocr';
}

export class InvoicePipeline {
  constructor(
    private readonly ingestion: FileIngestionService,
    private readonly ocr: OcrService,
    private readonly parser: InvoiceParser,
  ) {}

  async process(file: File, onProgress?: ProgressCallback): Promise<ProcessedInvoice> {
    const document = this.ingestion.ingest(file);
    const extraction = await this.ocr.extractText(document, onProgress);
    const text = extraction.text.trim();
    if (!text) {
      throw new Error('V dokumentu se nepodařilo najít žádný čitelný text.');
    }

    const parsable = normalizeText(text);
    const lines = normalizeLines(parsable);
    const parsed = this.parser.parse({ text: parsable, lines, blocks: analyzeTextBlocks(lines) });
    const extracted: ExtractedInvoice = parsed.data;

    return {
      data: { ...extracted, ambiguities: buildAmbiguities(extracted, parsed.ambiguities) },
      rawText: text,
      textSource: extraction.method,
    };
  }
}
