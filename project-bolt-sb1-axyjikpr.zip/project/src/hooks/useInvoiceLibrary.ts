import { useCallback, useEffect, useState } from 'react';
import type { StoredInvoice } from '@/types/invoice';
import { storage } from '@/app/services';
import { errorMessage } from '@/lib/errors';

export type LibraryStatus = 'loading' | 'ready' | 'error';

export function useInvoiceLibrary() {
  const [invoices, setInvoices] = useState<StoredInvoice[]>([]);
  const [status, setStatus] = useState<LibraryStatus>('loading');
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    setStatus('loading');
    try {
      setInvoices(await storage.listInvoices());
      setError(null);
      setStatus('ready');
    } catch (cause) {
      setError(errorMessage(cause));
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const upsert = useCallback((invoice: StoredInvoice) => {
    setInvoices((current) => {
      const exists = current.some((item) => item.id === invoice.id);
      return exists ? current.map((item) => (item.id === invoice.id ? invoice : item)) : [invoice, ...current];
    });
  }, []);

  const remove = useCallback((id: string) => {
    setInvoices((current) => current.filter((item) => item.id !== id));
  }, []);

  return { invoices, status, error, refresh, upsert, remove };
}
