import type { StoredInvoice } from '@/types/invoice';
import type { ExportPreview } from '@/preview/previewBuilder';

export interface ExportPayload {
  invoices: StoredInvoice[];
  preview: ExportPreview;
}

export interface IExporter {
  readonly format: string;
  readonly extension: string;
  readonly mimeType: string;
  export(payload: ExportPayload): Blob;
}
