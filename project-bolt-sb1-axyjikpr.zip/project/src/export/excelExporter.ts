import * as XLSX from 'xlsx';
import type { IExporter, ExportPayload } from '@/export/exportTypes';

export class ExcelExporter implements IExporter {
  readonly format = 'xlsx';
  readonly extension = 'xlsx';
  readonly mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

  export({ preview }: ExportPayload): Blob {
    const workbook = XLSX.utils.book_new();
    for (const sheet of preview.sheets) {
      const worksheet = XLSX.utils.aoa_to_sheet([sheet.headers, ...sheet.rows]);
      worksheet['!cols'] = sheet.headers.map((header) => ({ wch: Math.max(14, header.length + 2) }));
      XLSX.utils.book_append_sheet(workbook, worksheet, sheet.name);
    }
    const bytes = XLSX.write(workbook, { type: 'array', bookType: 'xlsx' }) as ArrayBuffer;
    return new Blob([bytes], { type: this.mimeType });
  }
}
