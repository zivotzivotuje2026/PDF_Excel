import type { CellValue, SheetName } from '@/preview/previewBuilder';
import type { IExporter, ExportPayload } from '@/export/exportTypes';

const DELIMITER = ';';

export class CsvExporter implements IExporter {
  readonly format = 'csv';
  readonly extension = 'csv';
  readonly mimeType = 'text/csv;charset=utf-8';

  constructor(private readonly sheetName: SheetName) {}

  export({ preview }: ExportPayload): Blob {
    const sheet = preview.sheets.find((candidate) => candidate.name === this.sheetName);
    const lines = sheet ? [sheet.headers, ...sheet.rows].map((row) => row.map(escapeCell).join(DELIMITER)) : [];
    return new Blob(['\uFEFF' + lines.join('\r\n')], { type: this.mimeType });
  }
}

function escapeCell(value: CellValue): string {
  if (value === null) return '';
  const text = String(value);
  return /[";\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}
