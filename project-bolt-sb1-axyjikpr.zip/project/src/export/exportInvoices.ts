import type { StoredInvoice } from '@/types/invoice';
import { buildExportPreview } from '@/preview/previewBuilder';
import { downloadBlob } from '@/lib/download';
import { EXPORT_FORMATS, storage, type ExportFormat } from '@/app/services';

export async function exportInvoices(format: ExportFormat, invoices: StoredInvoice[], baseName: string): Promise<void> {
  const blob = format.exporter.export({ invoices, preview: buildExportPreview(invoices) });
  const extension = format.exporter.extension;
  downloadBlob(blob, `${safeFileName(baseName)}${format.fileSuffix}.${extension}`);
  await Promise.all(
    invoices.map((invoice) => storage.appendAudit(invoice.id, 'export', { format: format.id })),
  );
}

export function findFormat(id: ExportFormat['id']): ExportFormat {
  const format = EXPORT_FORMATS.find((candidate) => candidate.id === id);
  if (!format) throw new Error(`Neznámý formát exportu: ${id}`);
  return format;
}

function safeFileName(name: string): string {
  return name.replace(/[^\p{L}\p{N}._-]+/gu, '_').replace(/^_+|_+$/g, '') || 'export';
}
