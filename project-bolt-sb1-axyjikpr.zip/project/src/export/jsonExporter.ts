import type { IExporter, ExportPayload } from '@/export/exportTypes';

export class JsonExporter implements IExporter {
  readonly format = 'json';
  readonly extension = 'json';
  readonly mimeType = 'application/json';

  export({ invoices }: ExportPayload): Blob {
    const body = {
      exportedAt: new Date().toISOString(),
      invoices: invoices.map((invoice) => ({
        fileName: invoice.fileName,
        status: invoice.status,
        ...invoice.data,
      })),
    };
    return new Blob([JSON.stringify(body, null, 2)], { type: this.mimeType });
  }
}
