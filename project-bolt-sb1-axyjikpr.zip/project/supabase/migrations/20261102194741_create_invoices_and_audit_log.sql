/*
# Create invoices and audit log (single-tenant, no auth)

Plain-English summary
The app stores each processed invoice with its extracted data and keeps an audit trail of every change (upload, parse, manual correction, verification, export).

1. New Tables
- `invoices`: one row per invoice. Denormalised columns (invoice_number, supplier_name, customer_name, total_amount, currency, status) power the list view; the full extracted structure lives in `data` (jsonb) and the raw OCR text in `raw_text`.
- `audit_log`: append-only log of actions on an invoice, with free-form `details` (jsonb).

2. Security
- RLS enabled on both tables.
- The app has no sign-in, so policies target `anon` and `authenticated`.
- `audit_log` is append-only: only SELECT and INSERT are granted and policied; UPDATE and DELETE are not.

3. Important notes
- Rows are intentionally shared by everyone using the app (no accounts).
- Child audit rows are removed automatically if their invoice is deleted.
*/

CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  file_name text NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'verified')),
  invoice_number text,
  supplier_name text,
  customer_name text,
  total_amount numeric,
  currency text,
  raw_text text NOT NULL DEFAULT '',
  data jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS invoices_created_at_idx ON invoices (created_at DESC);

CREATE TABLE IF NOT EXISTS audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  action text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audit_log_invoice_id_idx ON audit_log (invoice_id, created_at);

ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON invoices TO anon, authenticated;
GRANT SELECT, INSERT ON audit_log TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_invoices" ON invoices;
CREATE POLICY "anon_select_invoices" ON invoices FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_invoices" ON invoices;
CREATE POLICY "anon_insert_invoices" ON invoices FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_invoices" ON invoices;
CREATE POLICY "anon_update_invoices" ON invoices FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_invoices" ON invoices;
CREATE POLICY "anon_delete_invoices" ON invoices FOR DELETE
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_select_audit_log" ON audit_log;
CREATE POLICY "anon_select_audit_log" ON audit_log FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_audit_log" ON audit_log;
CREATE POLICY "anon_insert_audit_log" ON audit_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);
